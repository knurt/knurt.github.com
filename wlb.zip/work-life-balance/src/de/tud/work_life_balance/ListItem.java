package de.tud.work_life_balance;

import android.graphics.drawable.Drawable;

/**
 * Diese Klasse stellt einen Eintrag in einer Liste da, der aus einem Symbol und
 * einem Text besteht.
 * 
 * @see ListItemAdapter
 * 
 */
public class ListItem {
	
	/**
	 * Ein Text. Steht in der Liste meistens rechts.
	 */
	public String text;

	/**
	 * Ein kleines Bild. Steht in der Liste meistens links.
	 */
	private Drawable thumbnail;

	public ListItem(String text, Drawable thumbnail) {

		this.setThumbnail(thumbnail);

		this.text = text;

	}

	public void setThumbnail(Drawable thumbnail) {
		this.thumbnail = thumbnail;
	}
	
	public Drawable getThumbnail() {
		return thumbnail;
	}
}
