/**
 * Dieses Paket enthaelt alle Klassen, die zur Work-Life-Balance-App gehoeren.
 */
package de.tud.work_life_balance;