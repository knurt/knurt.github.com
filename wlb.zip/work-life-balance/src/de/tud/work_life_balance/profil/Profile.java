package de.tud.work_life_balance.profil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;

import de.tud.work_life_balance.calendar.Appointment;
import de.tud.work_life_balance.calendar.Calendar;


/**
 * Sammlung aller relevanten Daten ueber einen Nutzer.
 * <p>
 * Wird fuer die Datensicherung serialisiert.
 *
 */
public class Profile implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String firstName;
	private String FamilyName;
	private int age;
	private LinkedList<ProfilLocations> locations;
	private profilEinstellungen einstellungen;
	private LinkedList<Appointment> termine;
	private LinkedList<ProfilGewichtungen> gewichtungen;
	private LinkedList<String> gebuchteModule;
	private boolean infoTourStarten;
	private LinkedList<Calendar> kalenderListe;
	private ArrayList<String> orte;
	
	
	//zum testen hergestellt
	public Profile() {
		super();
		this.kalenderListe = new LinkedList<Calendar>();
		this.kalenderListe.add(new Calendar());
		this.infoTourStarten=true;
		this.einstellungen=new profilEinstellungen();
		this.orte= new ArrayList<String>();
	}

	public LinkedList<Appointment> getTermine() {
		return termine;
	}
	
	public void setTermine(LinkedList<Appointment> termine) {
		this.termine = termine;
	}
	
	public LinkedList<Calendar> getKalenderListe() {
		return kalenderListe;
	}
	
	public void setKalenderListe(LinkedList<Calendar> kalenderListe) {
		this.kalenderListe = kalenderListe;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getFamilyName() {
		return FamilyName;
	}
	public void setFamilyName(String familyName) {
		FamilyName = familyName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public LinkedList<ProfilLocations> getLocations() {
		return locations;
	}
	public void setLocations(LinkedList<ProfilLocations> locations) {
		this.locations = locations;
	}
	public profilEinstellungen getEinstellungen() {
		return einstellungen;
	}
	public void setEinstellungen(profilEinstellungen einstellungen) {
		this.einstellungen = einstellungen;
	}
	public LinkedList<ProfilGewichtungen> getGewichtungen() {
		return gewichtungen;
	}
	public void setGewichtungen(LinkedList<ProfilGewichtungen> gewichtungen) {
		this.gewichtungen = gewichtungen;
	}
	public LinkedList<String> getGebuchteModule() {
		return gebuchteModule;
	}
	public void setGebuchteModule(LinkedList<String> gebuchteModule) {
		this.gebuchteModule = gebuchteModule;
	}

	/**
	 * @return the infoTourStarten
	 */
	public boolean isInfoTourStarten() {
		return infoTourStarten;
	}

	/**
	 * @param infoTourStarten the infoTourStarten to set
	 */
	public void setInfoTourStarten(boolean infoTourStarten) {
		this.infoTourStarten = infoTourStarten;
	}

	/**
	 * @return the orte
	 */
	public ArrayList<String> getOrte() {
		return orte;
	}

	/**
	 * @param orte the orte to set
	 */
	public void setOrte(ArrayList<String> orte) {
		this.orte = orte;
	}

	
	

}
