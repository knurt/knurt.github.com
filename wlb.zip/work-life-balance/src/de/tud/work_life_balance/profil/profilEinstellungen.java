package de.tud.work_life_balance.profil;

import java.io.Serializable;

public class profilEinstellungen implements Serializable {

	// TODO Das profil muss noch löschbar sein, das muss matze in seinen
	// Einstellungen arangieren

	private static final long serialVersionUID = 1L;
	private boolean localityActivation;
	private int nachrichtenton;
	private boolean benachrichtigung;
	private boolean ton;
	private boolean vibration;
	private boolean datenfreigabe;

	public profilEinstellungen() {
		super();
		localityActivation = false;
		nachrichtenton = 1;
		benachrichtigung = true;
		ton = true;
		vibration = false;
		datenfreigabe = false;

	}

	/**
	 * @return the localityActivation
	 */
	public boolean isLocalityActivation() {
		return localityActivation;
	}

	/**
	 * @return the nachrichtenton
	 */
	public int getNachrichtenton() {
		return nachrichtenton;
	}

	/**
	 * @return the benachrichtigung
	 */
	public boolean isBenachrichtigung() {
		return benachrichtigung;
	}

	/**
	 * @return the toene
	 */
	public boolean isTon() {
		return ton;
	}

	/**
	 * @return the datenfreigabe
	 */
	public boolean isDatenfreigabe() {
		return datenfreigabe;
	}

	/**
	 * @param localityActivation
	 *            the localityActivation to set
	 */
	public void setLocalityActivation(boolean localityActivation) {
		this.localityActivation = localityActivation;
	}

	/**
	 * @param benachrichtigung
	 *            the benachrichtigung to set
	 */
	public void setBenachrichtigung(boolean benachrichtigung) {
		this.benachrichtigung = benachrichtigung;
	}

	/**
	 * @param toene
	 *            the toene to set
	 */
	public void setTon(boolean ton) {
		this.ton = ton;
	}

	/**
	 * @return the vibration
	 */
	public boolean isVibration() {
		return vibration;
	}

	/**
	 * @param vibration
	 *            the vibration to set
	 */
	public void setVibration(boolean vibration) {
		this.vibration = vibration;
	}

	/**
	 * @param datenfreigabe
	 *            the datenfreigabe to set
	 */
	public void setDatenfreigabe(boolean datenfreigabe) {
		this.datenfreigabe = datenfreigabe;
	}

	public void setNachrichtenton(int chosen) {
		if (chosen > 2 || chosen < 0) {
			nachrichtenton = 0;
		} else {
			nachrichtenton = chosen;
		}
	}

}
