package de.tud.work_life_balance.profil;

import java.io.Serializable;

/**
 * Nutzerspezifische Gewichtungen der vier Lebensbereiche.
 * <p>
 * Ist noch nicht implementiert.
 *
 */
public class ProfilGewichtungen implements Serializable {
	
	private static final long serialVersionUID = 1L;

}
