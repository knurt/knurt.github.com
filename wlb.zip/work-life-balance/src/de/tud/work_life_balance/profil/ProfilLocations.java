package de.tud.work_life_balance.profil;

import java.io.Serializable;

/**
 * Klasse fuer die Speicherung von Orten im Profil
 *
 */
public class ProfilLocations implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private long xCoordinate;
	private long yCoordinate;
	private String locationName;

	public ProfilLocations(String locationname, long xCoordinate, long yCoordinate) {
		
		this.locationName = locationname;
		this.xCoordinate = xCoordinate;
		this.yCoordinate = yCoordinate;
	}

	public long getxCoordinate() {
		return xCoordinate;
	}

	public void setxCoordinate(long xCoordinate) {
		this.xCoordinate = xCoordinate;
	}

	public long getyCoordinate() {
		return yCoordinate;
	}

	public void setyCoordinate(long yCoordinate) {
		this.yCoordinate = yCoordinate;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
}
