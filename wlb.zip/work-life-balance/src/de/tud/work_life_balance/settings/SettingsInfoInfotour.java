package de.tud.work_life_balance.settings;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import de.tud.work_life_balance.R;

/**
 * Diese Klasse baut eine Activity auf welche die Infotour beinhaltet
 * 
 * @author Matthias Conrad
 *
 */

public class SettingsInfoInfotour extends Activity {
	
	//zaehlt auf welcher seite man in der infotour ist
	int counter=0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.infotour_startseite);
	}

	/**
	 * startet die Infotour
	 * @param view Button welcher gedr�ckt wurde
	 */
	public void startInfotour(View view){
		
		//Infotour wird �ber das Einstellungsmenue gestartet
		if(view.getId()== R.id.startbutton){
		
		setContentView(R.layout.infotour_h1);
		}
		//Infotour wird beim ersten Start der App mit einem Begr��ungstext gestartet
		else{
			setContentView(R.layout.infotour_startseite);
		}
	}
	
	/**
	 * 
	 * steuert die klicks auf die Buttons in der Infotour
	 * 
	 * @param view Der Button welcher geklickt wurde
	 */
	public void klick(View view){
		
		
		//info1
		if(view.getId() == R.id.infotour_imageView1){
		
			TextView text1=(TextView) findViewById(R.id.infotourtext);
			text1.setText(R.string.infotour_button1);

			ImageView tip = (ImageView) findViewById(R.id.infotour_imageView2);
			tip.setVisibility(View.VISIBLE);

			ImageView tip1 = (ImageView) findViewById(R.id.textfeld_imageView1);
			tip1.setImageResource(R.drawable.tap1);
			tip1.setVisibility(View.VISIBLE);

			ImageView tip2 = (ImageView) findViewById(R.id.infotour_imageView3);
			tip2.setVisibility(View.INVISIBLE);

			// Rahmen setzen
			ImageView l1 = (ImageView) findViewById(R.id.line_imageView1);
			l1.setVisibility(View.VISIBLE);

			ImageView l2 = (ImageView) findViewById(R.id.line_imageView2);
			l2.setVisibility(View.VISIBLE);

			ImageView l3 = (ImageView) findViewById(R.id.line_imageView3);
			l3.setVisibility(View.VISIBLE);

			ImageView l4 = (ImageView) findViewById(R.id.line_imageView4);
			l4.setVisibility(View.VISIBLE);

			// Rahmen l�schen
			ImageView l5 = (ImageView) findViewById(R.id.line_imageView5);
			l5.setVisibility(View.INVISIBLE);

			ImageView l6 = (ImageView) findViewById(R.id.line_imageView6);
			l6.setVisibility(View.INVISIBLE);

			ImageView l7 = (ImageView) findViewById(R.id.line_imageView7);
			l7.setVisibility(View.INVISIBLE);

			ImageView l8 = (ImageView) findViewById(R.id.line_imageView8);
			l8.setVisibility(View.INVISIBLE);

			ImageView l9 = (ImageView) findViewById(R.id.line_imageView9);
			l9.setVisibility(View.INVISIBLE);

			ImageView l10 = (ImageView) findViewById(R.id.line_imageView10);
			l10.setVisibility(View.INVISIBLE);

		}

		if (view.getId() == R.id.infotour_imageView4) {

			TextView text1 = (TextView) findViewById(R.id.infotourtext);
			text1.setText(R.string.infotour_button2);

			ImageView tip1 = (ImageView) findViewById(R.id.infotour_imageView3);
			tip1.setVisibility(View.VISIBLE);

			ImageView tip = (ImageView) findViewById(R.id.textfeld_imageView1);
			tip.setImageResource(R.drawable.tap2);

			ImageView tip2 = (ImageView) findViewById(R.id.infotour_imageView2);
			tip2.setVisibility(View.INVISIBLE);

			// Rahmen l�schen
			ImageView l1 = (ImageView) findViewById(R.id.line_imageView1);
			l1.setVisibility(View.INVISIBLE);

			ImageView l2 = (ImageView) findViewById(R.id.line_imageView2);
			l2.setVisibility(View.INVISIBLE);

			ImageView l3 = (ImageView) findViewById(R.id.line_imageView3);
			l3.setVisibility(View.INVISIBLE);

			ImageView l8 = (ImageView) findViewById(R.id.line_imageView8);
			l8.setVisibility(View.INVISIBLE);

			ImageView l9 = (ImageView) findViewById(R.id.line_imageView9);
			l9.setVisibility(View.INVISIBLE);

			ImageView l10 = (ImageView) findViewById(R.id.line_imageView10);
			l10.setVisibility(View.INVISIBLE);

			// rahmen setzen
			ImageView l4 = (ImageView) findViewById(R.id.line_imageView4);
			l4.setVisibility(View.VISIBLE);

			ImageView l5 = (ImageView) findViewById(R.id.line_imageView5);
			l5.setVisibility(View.VISIBLE);

			ImageView l6 = (ImageView) findViewById(R.id.line_imageView6);
			l6.setVisibility(View.VISIBLE);

			ImageView l7 = (ImageView) findViewById(R.id.line_imageView7);
			l7.setVisibility(View.VISIBLE);

		}

		if (view.getId() == R.id.infotour_imageView5) {

			TextView text1 = (TextView) findViewById(R.id.infotourtext);
			text1.setText(R.string.infotour_button3);

			ImageView tip = (ImageView) findViewById(R.id.textfeld_imageView1);
			tip.setImageResource(R.drawable.tap3);

			ImageView tip2 = (ImageView) findViewById(R.id.infotour_imageView2);
			tip2.setVisibility(View.INVISIBLE);

			ImageView tip1 = (ImageView) findViewById(R.id.infotour_imageView3);
			tip1.setVisibility(View.INVISIBLE);

			// Rahmen l�schen

			ImageView l1 = (ImageView) findViewById(R.id.line_imageView1);
			l1.setVisibility(View.INVISIBLE);

			ImageView l2 = (ImageView) findViewById(R.id.line_imageView2);
			l2.setVisibility(View.INVISIBLE);

			ImageView l3 = (ImageView) findViewById(R.id.line_imageView3);
			l3.setVisibility(View.INVISIBLE);

			ImageView l4 = (ImageView) findViewById(R.id.line_imageView4);
			l4.setVisibility(View.INVISIBLE);

			ImageView l6 = (ImageView) findViewById(R.id.line_imageView6);
			l6.setVisibility(View.INVISIBLE);

			ImageView l7 = (ImageView) findViewById(R.id.line_imageView7);
			l7.setVisibility(View.INVISIBLE);

			// Rahmen setzen

			ImageView l5 = (ImageView) findViewById(R.id.line_imageView5);
			l5.setVisibility(View.VISIBLE);

			ImageView l8 = (ImageView) findViewById(R.id.line_imageView8);
			l8.setVisibility(View.VISIBLE);

			ImageView l9 = (ImageView) findViewById(R.id.line_imageView9);
			l9.setVisibility(View.VISIBLE);

			ImageView l10 = (ImageView) findViewById(R.id.line_imageView10);
			l10.setVisibility(View.VISIBLE);

		}

		// info2
		if (view.getId() == R.id.infotour_imageView6) {

			TextView text1 = (TextView) findViewById(R.id.infotourtext);
			text1.setText(R.string.infotour_button1_2);

			ImageView tip1 = (ImageView) findViewById(R.id.infotour_imageView9);
			tip1.setVisibility(View.VISIBLE);

			ImageView tip = (ImageView) findViewById(R.id.textfeld_imageView1);
			tip.setImageResource(R.drawable.tap1);
			tip.setVisibility(View.VISIBLE);

			// Rahmen setzen
			ImageView l11 = (ImageView) findViewById(R.id.line_imageView11);
			l11.setVisibility(View.VISIBLE);

			ImageView l12 = (ImageView) findViewById(R.id.line_imageView12);
			l12.setVisibility(View.VISIBLE);

			ImageView l13 = (ImageView) findViewById(R.id.line_imageView13);
			l13.setVisibility(View.VISIBLE);

			ImageView l14 = (ImageView) findViewById(R.id.line_imageView14);
			l14.setVisibility(View.VISIBLE);

			// Rahmen l�schen
			ImageView l15 = (ImageView) findViewById(R.id.line_imageView15);
			l15.setVisibility(View.INVISIBLE);

			ImageView l16 = (ImageView) findViewById(R.id.line_imageView16);
			l16.setVisibility(View.INVISIBLE);

			ImageView l17 = (ImageView) findViewById(R.id.line_imageView17);
			l17.setVisibility(View.INVISIBLE);

			ImageView l18 = (ImageView) findViewById(R.id.line_imageView18);
			l18.setVisibility(View.INVISIBLE);

			ImageView l19 = (ImageView) findViewById(R.id.line_imageView19);
			l19.setVisibility(View.INVISIBLE);

			ImageView l20 = (ImageView) findViewById(R.id.line_imageView20);
			l20.setVisibility(View.INVISIBLE);

		}

		if (view.getId() == R.id.infotour_imageView7) {

			TextView text1 = (TextView) findViewById(R.id.infotourtext);
			text1.setText(R.string.infotour_button2_2);

			ImageView tip = (ImageView) findViewById(R.id.textfeld_imageView1);
			tip.setImageResource(R.drawable.tap2);

			ImageView tip1 = (ImageView) findViewById(R.id.infotour_imageView9);
			tip1.setVisibility(View.INVISIBLE);

			// Rahmen l�schen
			ImageView l11 = (ImageView) findViewById(R.id.line_imageView11);
			l11.setVisibility(View.INVISIBLE);

			ImageView l12 = (ImageView) findViewById(R.id.line_imageView12);
			l12.setVisibility(View.INVISIBLE);

			ImageView l13 = (ImageView) findViewById(R.id.line_imageView13);
			l13.setVisibility(View.INVISIBLE);

			ImageView l18 = (ImageView) findViewById(R.id.line_imageView18);
			l18.setVisibility(View.INVISIBLE);

			ImageView l19 = (ImageView) findViewById(R.id.line_imageView19);
			l19.setVisibility(View.INVISIBLE);

			ImageView l20 = (ImageView) findViewById(R.id.line_imageView20);
			l20.setVisibility(View.INVISIBLE);

			// rahmen setzen
			ImageView l14 = (ImageView) findViewById(R.id.line_imageView14);
			l14.setVisibility(View.VISIBLE);

			ImageView l15 = (ImageView) findViewById(R.id.line_imageView15);
			l15.setVisibility(View.VISIBLE);

			ImageView l16 = (ImageView) findViewById(R.id.line_imageView16);
			l16.setVisibility(View.VISIBLE);

			ImageView l17 = (ImageView) findViewById(R.id.line_imageView17);
			l17.setVisibility(View.VISIBLE);
		}

		if (view.getId() == R.id.infotour_imageView8) {

			TextView text1 = (TextView) findViewById(R.id.infotourtext);
			text1.setText(R.string.infotour_button3_2);

			ImageView tip = (ImageView) findViewById(R.id.textfeld_imageView1);
			tip.setImageResource(R.drawable.tap3);

			ImageView tip1 = (ImageView) findViewById(R.id.infotour_imageView9);
			tip1.setVisibility(View.INVISIBLE);

			// Rahmen l�schen

			ImageView l11 = (ImageView) findViewById(R.id.line_imageView11);
			l11.setVisibility(View.INVISIBLE);

			ImageView l12 = (ImageView) findViewById(R.id.line_imageView12);
			l12.setVisibility(View.INVISIBLE);

			ImageView l13 = (ImageView) findViewById(R.id.line_imageView13);
			l13.setVisibility(View.INVISIBLE);

			ImageView l14 = (ImageView) findViewById(R.id.line_imageView14);
			l14.setVisibility(View.INVISIBLE);

			ImageView l16 = (ImageView) findViewById(R.id.line_imageView16);
			l16.setVisibility(View.INVISIBLE);

			ImageView l17 = (ImageView) findViewById(R.id.line_imageView17);
			l17.setVisibility(View.INVISIBLE);

			// Rahmen setzen

			ImageView l15 = (ImageView) findViewById(R.id.line_imageView15);
			l15.setVisibility(View.VISIBLE);

			ImageView l18 = (ImageView) findViewById(R.id.line_imageView18);
			l18.setVisibility(View.VISIBLE);

			ImageView l19 = (ImageView) findViewById(R.id.line_imageView19);
			l19.setVisibility(View.VISIBLE);

			ImageView l20 = (ImageView) findViewById(R.id.line_imageView20);
			l20.setVisibility(View.VISIBLE);
		}

		// info3

		if (view.getId() == R.id.infotour_imageView11) {

			TextView text1 = (TextView) findViewById(R.id.infotourtext);
			text1.setText(R.string.infotour_button1_3);

			ImageView tip1 = (ImageView) findViewById(R.id.infotour_imageView14);
			tip1.setVisibility(View.VISIBLE);

			ImageView tip = (ImageView) findViewById(R.id.textfeld_imageView1);
			tip.setImageResource(R.drawable.tap1);
			tip.setVisibility(View.VISIBLE);

			ImageView tip2 = (ImageView) findViewById(R.id.infotour_imageView13);
			tip2.setVisibility(View.INVISIBLE);

			ImageView tip3 = (ImageView) findViewById(R.id.infotour_imageView15);
			tip3.setVisibility(View.INVISIBLE);

			// Rahmen setzen
			ImageView l21 = (ImageView) findViewById(R.id.line_imageView21);
			l21.setVisibility(View.VISIBLE);

			ImageView l22 = (ImageView) findViewById(R.id.line_imageView22);
			l22.setVisibility(View.VISIBLE);

			ImageView l23 = (ImageView) findViewById(R.id.line_imageView23);
			l23.setVisibility(View.VISIBLE);

			ImageView l24 = (ImageView) findViewById(R.id.line_imageView24);
			l24.setVisibility(View.VISIBLE);

			// Rahmen l�schen

			ImageView l25 = (ImageView) findViewById(R.id.line_imageView25);
			l25.setVisibility(View.INVISIBLE);

			ImageView l26 = (ImageView) findViewById(R.id.line_imageView26);
			l26.setVisibility(View.INVISIBLE);

			ImageView l27 = (ImageView) findViewById(R.id.line_imageView27);
			l27.setVisibility(View.INVISIBLE);

			ImageView l28 = (ImageView) findViewById(R.id.line_imageView28);
			l28.setVisibility(View.INVISIBLE);
		}

		if (view.getId() == R.id.infotour_imageView12) {

			TextView text1 = (TextView) findViewById(R.id.infotourtext);
			text1.setText(R.string.infotour_button2_3);

			ImageView tip1 = (ImageView) findViewById(R.id.infotour_imageView13);
			tip1.setVisibility(View.VISIBLE);

			ImageView tip = (ImageView) findViewById(R.id.infotour_imageView15);
			tip.setVisibility(View.VISIBLE);

			ImageView tip2 = (ImageView) findViewById(R.id.textfeld_imageView1);
			tip2.setImageResource(R.drawable.tap2);

			ImageView tip3 = (ImageView) findViewById(R.id.infotour_imageView14);
			tip3.setVisibility(View.INVISIBLE);

			// Rahmen setzen
			ImageView l25 = (ImageView) findViewById(R.id.line_imageView25);
			l25.setVisibility(View.VISIBLE);

			ImageView l26 = (ImageView) findViewById(R.id.line_imageView26);
			l26.setVisibility(View.VISIBLE);

			ImageView l27 = (ImageView) findViewById(R.id.line_imageView27);
			l27.setVisibility(View.VISIBLE);

			ImageView l28 = (ImageView) findViewById(R.id.line_imageView28);
			l28.setVisibility(View.VISIBLE);

			// Rahmen l�schen
			ImageView l21 = (ImageView) findViewById(R.id.line_imageView21);
			l21.setVisibility(View.INVISIBLE);

			ImageView l22 = (ImageView) findViewById(R.id.line_imageView22);
			l22.setVisibility(View.INVISIBLE);

			ImageView l23 = (ImageView) findViewById(R.id.line_imageView23);
			l23.setVisibility(View.INVISIBLE);

			ImageView l24 = (ImageView) findViewById(R.id.line_imageView24);
			l24.setVisibility(View.INVISIBLE);
		}
	}
	
	
	/**
	 * bl�ttert eine Seite zur�ck
	 * 
	 * @param view Der Button welcher gedr�ckt wurde
	 */
	public void pageBack(View view) {
		
		switch(counter) {

		case 0:

			setContentView(R.layout.infotour_startseite);

			break;

		case 1:

			setContentView(R.layout.infotour_h1);

			TextView text1 = (TextView) findViewById(R.id.infotourtext);
			text1.setText(R.string.infotour_erklaertext_1);
			counter--;

			break;

		case 2:

			setContentView(R.layout.infotour_h2);

			TextView text2 = (TextView) findViewById(R.id.infotourtext);
			text2.setText(R.string.infotour_erklaertext_2);
			counter--;

			break;

		default:
			finish();
		}

	}
	
	
	/**
	 * bl�ttert eine Seite vor
	 * 
	 * @param view
	 */
	
	public void nextPage(View view) {
		
		switch(counter) {
		
		case 0:

			setContentView(R.layout.infotour_h2);

			TextView text2 = (TextView) findViewById(R.id.infotourtext);
			text2.setText(R.string.infotour_erklaertext_2);

			counter++;

			break;

		case 1:

			setContentView(R.layout.infotour_h3);

			TextView text3 = (TextView) findViewById(R.id.infotourtext);
			text3.setText(R.string.infotour_erklaertext_3);

			Button weiter = (Button) findViewById(R.id.button1);
			weiter.setText(R.string.infotour_ende);

			counter++;

			break;

		default:
			finish();
		}

	}

}
