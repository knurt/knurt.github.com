package de.tud.work_life_balance.settings;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import de.tud.work_life_balance.R;

/**
 * Diese Klasse stellt einen Adapter f�r Listenelemente dar, welche in den Activities der Einstellungen verwendet wird
 * 
 * @author Matthias Conrad
 *
 */
public class SettingsItemAdapter extends ArrayAdapter<SettingsListItem>  {

	private ArrayList<SettingsListItem> items;
	
	 public SettingsItemAdapter(Context context, int textViewResourceId, ArrayList<SettingsListItem> items) {

	        super(context, textViewResourceId, items);

	  this.items = items;

	    }
	 
	 
	 @Override

	    public View getView(int position, View convertView, ViewGroup parent) {

	        View v = convertView;

	  if (v == null) {

	            LayoutInflater vi = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

	            v = vi.inflate(R.layout.einstellungs_list_item, null);

	  }

	      

	  SettingsListItem item = items.get(position);

	  if (item != null) {

	            TextView menueS = (TextView) v.findViewById(R.id.menueS);
	            
	            ImageView image = (ImageView) v.findViewById(R.id.avatar);



	      if (item != null) {

	                menueS.setText(item.setting);
	                
	                if(item.thumbnail!= null){
	                	
	                image.setImageDrawable(item.thumbnail);
	                	
	                }

	      }
	      



	    

	  }

	  return v;

	    }
	 
	 

	}
	 
	

