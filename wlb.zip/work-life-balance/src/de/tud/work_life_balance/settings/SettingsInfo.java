package de.tud.work_life_balance.settings;

import java.util.ArrayList;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import de.tud.work_life_balance.MainActivity;
import de.tud.work_life_balance.R;
import de.tud.work_life_balance.TagesViewActivity;


/**
 * Die Klasse  baut eine Activity auf welche Infos �ber Datenschutz, Lizenz ect. enth�lt
 * 
 * @author Matthias Conrad
 *
 */
public class SettingsInfo extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_einstellungen_info);
		
		final ActionBar actionBar = getActionBar();
		actionBar.setDisplayHomeAsUpEnabled(true);
		
		buildActivity();
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_einstellungen_info, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
	    switch (item.getItemId()) {
	        case android.R.id.home:
	            // app icon in action bar clicked; go home
	            Intent intent = new Intent(this, MainActivity.class);
	            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	            startActivity(intent);
	            return true;
	            
	        case R.id.openDayView:
	        	Intent oDV = new Intent(this, TagesViewActivity.class);
	        	startActivity(oDV);
	        	
	            
	        default:
	            return super.onOptionsItemSelected(item);
	    }
	}
	
	/**
	 * startet die Activity  �ber Datenschutz
	 */
	private void infoPrivacyPolicy(){
		
	
    	startActivity(new Intent(this, de.tud.work_life_balance.settings.SettingsInfoPrivacyPolicy.class));

	}
	
	/**
	 * startet die Activity  �ber Lizenz
	 */
	private void infoLicense(){
		
    	
    	startActivity(new Intent(this, de.tud.work_life_balance.settings.SettingsInfoLicense.class));

	}
	
	/**
	 * startet die Activity mit FAQ
	 */
	private void infoFAQ(){
		
    	
    	startActivity( new Intent(this, de.tud.work_life_balance.settings.SettingsInfoFAQ.class));

	}
	/**
	 * startet die Activity  mit der Infotour
	 */
	private void infoTutorial(){
		
		
    	startActivity(new Intent(this, de.tud.work_life_balance.settings.SettingsInfoInfotour.class));

	}
	
	/**
	 * startet die Activity  mit informationen �ber die Entwickler
	 */
	private void infoAbout(){
		
	
    	startActivity( new Intent(this, de.tud.work_life_balance.settings.SettingsInfoAbout.class));

	}
	
	
/**
 * Baut die Activity auf	
 */
private void buildActivity(){
    	
		ArrayList<SettingsListItem> infoMenue = new ArrayList<SettingsListItem>();
		    	
		    	
		    	
				infoMenue.add(new de.tud.work_life_balance.settings.SettingsListItem(getString(R.string.datenschutz), null));
				infoMenue.add(new de.tud.work_life_balance.settings.SettingsListItem(getString(R.string.lizenz), null));
				infoMenue.add(new de.tud.work_life_balance.settings.SettingsListItem(getString(R.string.faq), null));
				infoMenue.add(new de.tud.work_life_balance.settings.SettingsListItem(getString(R.string.infotour), null));
				infoMenue.add(new de.tud.work_life_balance.settings.SettingsListItem(getString(R.string.ueber), null));
				
				
		    	

		    	final ListView menueList = (ListView) findViewById(R.id.listView1);
		    	 
		    	
		    menueList.setAdapter(new SettingsItemAdapter(this, R.layout.listitem, infoMenue));	
		    
		    menueList.setOnItemClickListener(new OnItemClickListener() {
		        
		    	@Override
		        public void onItemClick(AdapterView<?> parent, View view, int position,
		                long id) {
		           
		    		
		    		
		    		
		    		switch(position){
		    		
		    		case 1:
		    			
		    			infoLicense();
		    		
		    			break;
		    		
		    		case 2:
		    			
		    			infoFAQ();
		    		
		    			break;
		    			
		    		case 3:
		        			
		            			
		            	infoTutorial();
		        	
		            	break;
		            	
		    		case 4:
		                			
		                infoAbout();
		               
		              break;
		            
		    		default:  infoPrivacyPolicy();

		    		
		    		}
		    		
		    	}
		        
		    });
		    
		    	
		    }


}
