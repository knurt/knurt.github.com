package de.tud.work_life_balance.settings;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;
import de.tud.work_life_balance.calendar.CalendarOverviewActivity;
import de.tud.work_life_balance.calendar.ShowAppointment;


/**
 * Diese Klasse ist ein Reciever welcher eine Erinnerung an das Handy sendet !
 * 
 * @author Matthias Conrad
 *
 */
public class AlarmReceiver extends BroadcastReceiver {

	
	private static int NotificationNumber=0;
	
	
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		
		long id = intent.getLongExtra("id", -1);
		
		//termin fuer die anzeige!
		String termin = intent.getStringExtra("name")+", "+intent.getStringExtra("startDate")
						+", "+intent.getStringExtra("startTime")+" Uhr";
		
		//notification setzen
		 showNotification(context,termin, id);

	}

	private void showNotification(Context context,String termin,long id){
		
		
		
		
		
		
		//sound
				Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

				//notification setzen
				NotificationCompat.Builder mBuilder =
				        new NotificationCompat.Builder(context)
				
				        .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
				        .setContentTitle("Work-Life-Balance")
				        .setSound(soundUri)
				        .setWhen(System.currentTimeMillis())
				        .setContentText(termin);
						
				//wird gel�scht wenn gesehen!
				mBuilder.setAutoCancel(true);
				
				// Anzeige beim anklicken der notification mit uebergabe der Termin ID
				Intent resultIntent = new Intent(context, ShowAppointment.class);
				resultIntent.putExtra(CalendarOverviewActivity.APPOINTMENT_ID, id);

				PendingIntent contentIntent = PendingIntent.getActivity(context, 0, resultIntent,PendingIntent.FLAG_ONE_SHOT);  
				     

				mBuilder.setContentIntent(contentIntent);
				NotificationManager mNotificationManager =
				    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
				
				mNotificationManager.notify(NotificationNumber, mBuilder.build());
				
				NotificationNumber++;
	}
}
