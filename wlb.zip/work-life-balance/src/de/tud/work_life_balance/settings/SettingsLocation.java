package de.tud.work_life_balance.settings;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import de.tud.work_life_balance.MainActivity;
import de.tud.work_life_balance.R;
import de.tud.work_life_balance.TagesViewActivity;


/**
 * Diese Klasse baut eine Activity auf, welche Einstellungen zur Standortbestimmung beinhaltet
 * 
 * @author Matthias Conrad
 *
 */
public class SettingsLocation extends Activity {

	boolean location;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_einstellungen_standort);
		
		final ActionBar actionBar = getActionBar();
		actionBar.setDisplayHomeAsUpEnabled(true);
		
		buildActivity();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_einstellungen_standort, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
	    switch (item.getItemId()) {
	        case android.R.id.home:
	            // app icon in action bar clicked; go home
	            Intent intent = new Intent(this, MainActivity.class);
	            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	            startActivity(intent);
	            return true;
	            
	        case R.id.openDayView:
	        	Intent oDV = new Intent(this, TagesViewActivity.class);
	        	startActivity(oDV);
	        	
	            
	        default:
	            return super.onOptionsItemSelected(item);
	    }
	}
	
	public void buildActivity(){
		
		CheckBox check = (CheckBox)findViewById(R.id.standort_checkBox);
		//laden
		if(MainActivity.getProfil().getEinstellungen().isLocalityActivation()){
			check.setChecked(true);
		}
		
		location=MainActivity.getProfil().getEinstellungen().isLocalityActivation();
		
		
		check.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				// TODO Auto-generated method stub
				
				CheckBox check= (CheckBox)findViewById(R.id.standort_checkBox);
				if(isChecked){
					
					check.setChecked(true);
					location=true;
				}
				else{
					check.setChecked(false);
					location=false;
				}
			}
		});
	}
	
	
	/**
	 * Eingabe best�tigen
	 * @param view Der Button welcher gedr�ckt wurde
	 */
	public void ok(View view){
		
		save();
		finish();
	}
	
	/**
	 * Eingabe wird abgebrochen
	 * @param view
	 */
	public void abbrechen(View view){
		
		finish();
		
	}

	/**
	 * Eingabe wird gespeichert
	 */
	public void save(){
		
		MainActivity.getProfil().getEinstellungen().setLocalityActivation(location);
	}
}
