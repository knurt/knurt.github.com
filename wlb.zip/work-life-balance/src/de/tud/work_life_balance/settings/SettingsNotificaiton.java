package de.tud.work_life_balance.settings;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.TextView;
import de.tud.work_life_balance.MainActivity;
import de.tud.work_life_balance.R;

/**
 * Dies Klasse baut eine Activity auf, welche Einstellungen �ber die
 * Benachrichtigung enthaelt!
 * 
 * @author Matthias Conrad
 * 
 */
public class SettingsNotificaiton extends Activity {

	Dialog dlg;
	int notificationSound;
	boolean notification;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_einstellungen_benachrichtigung);

		init();
		selectNotification();

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(
				R.menu.activity_einstellungen_benachrichtigung, menu);
		return true;
	}

	/**
	 * setzt Benachrichtigung an/aus
	 */
	public void selectNotification() {

		ListView list;
		CheckListAdapter adapter;

		list = (ListView) findViewById(R.id.benachrichtigungListView1);
		adapter = new CheckListAdapter(this, getResources().getStringArray(
				R.array.benachrichtigung_einstellungen));
		list.setAdapter(adapter);

		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {

				CheckedTextView tv = (CheckedTextView) arg1;
				if (tv.isChecked()) {
					// auswahl speichern
					notification = false;
					tv.setChecked(false);
				} else {
					// auswahl speichern
					notification = true;
					tv.setChecked(true);
				}
			}

		});

	}

	/**
	 * Ein Dialog zum ausw�len des Tones wir aufgebaut
	 * 
	 * @param view
	 *            Button welcher geklickt wurde
	 */
	public void selectSound(View view) {

		dlg = new Dialog(this);

		dlg.setContentView(R.layout.benachrichtigung_auswahl);
		dlg.setTitle(R.string.benachrichtigungen_nachrichtenton);
		dlg.show();
		// Dialoggroesse setzen
		WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
		lp.copyFrom(dlg.getWindow().getAttributes());
		lp.width = 470;
		lp.height = 500;
		lp.x = -170;
		lp.y = 50;
		dlg.getWindow().setAttributes(lp);

		// Dialog fuellen
		final ListView list = (ListView) dlg
				.findViewById(R.id.benachrichtigungAuswahlListView1);
		list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

		Button ok = (Button) dlg.findViewById(R.id.benachrichtigung_ok_button);
		Button abbruch = (Button) dlg
				.findViewById(R.id.benachrichtigung_abbruch_button);

		list.setAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_single_choice, getResources()
						.getStringArray(R.array.nachrichtenton)));

		// einstellung laden
		list.setItemChecked(notificationSound, true);

		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				switch (position) {

				case 0:

					if (view.isPressed()) {
						view.setPressed(false);
					} else
						view.setPressed(true);

					break;

				}

			}

		});

		ok.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				int pos = list.getCheckedItemPosition();

				// auswahl speichern
				notificationSound = (pos);

				TextView akt = (TextView) findViewById(R.id.benachrichtigung_zustandTV);
				switch (pos) {
				case 0:
					akt.setText(R.string.aus);
					break;
				case 1:
					akt.setText(R.string.ein);
					break;
				case 2:
					akt.setText(R.string.vibtartion);
					break;

				default:
					dlg.dismiss();

				}
				dlg.dismiss();

			}
		});

		abbruch.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				dlg.dismiss();

			}
		});

	}

	/**
	 * Einstellungen best�tigen
	 * 
	 * @param view
	 */
	public void ok(View view) {

		save();

		finish();
	}

	/**
	 * Einstellung abbrechen
	 * 
	 * @param view
	 *            Button welcher gedr�ckt wurde
	 */
	public void abbrechen(View view) {

		finish();
	}

	/**
	 * Einstellungen werden geladen
	 */
	public void init() {

		notification = MainActivity.getProfil().getEinstellungen()
				.isBenachrichtigung();
		notificationSound = MainActivity.getProfil().getEinstellungen()
				.getNachrichtenton();

		TextView akt = (TextView) findViewById(R.id.benachrichtigung_zustandTV);
		switch (notificationSound) {
		case 0:
			akt.setText(R.string.aus);
			break;
		case 1:
			akt.setText(R.string.ein);
			break;
		case 2:
			akt.setText(R.string.vibtartion);
			break;

		default:

		}

	}

	/**
	 * Einstellungen weden gespeicher
	 */
	public void save() {

		MainActivity.getProfil().getEinstellungen()
				.setBenachrichtigung(notification);
		MainActivity.getProfil().getEinstellungen()
				.setNachrichtenton(notificationSound);

	}

}
