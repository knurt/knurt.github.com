package de.tud.work_life_balance.settings;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.CheckedTextView;
import android.widget.ListView;
import de.tud.work_life_balance.MainActivity;
import de.tud.work_life_balance.R;
import de.tud.work_life_balance.TagesViewActivity;

/**
 * Diese Klasse baut eine Activity auf, in welcher man die Toneinstellungen aendern kann!
 * @author Matthias Conrad
 *
 */
public class SettingsSound extends Activity {
	
	
	ListView list;
	CheckListAdapter adapter;
	     
	     
	

	boolean sound;
	boolean vibration;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_einstellungen_ton);
	
		final ActionBar actionBar = getActionBar();
		actionBar.setDisplayHomeAsUpEnabled(true);
		
		//einstellungen laden(werden eigentlich im adapter geladen, hier wegen abbruch)!
		sound=MainActivity.getProfil().getEinstellungen().isTon();
		vibration=MainActivity.getProfil().getEinstellungen().isVibration();
		
		//CHECKEDLIST
		 list = (ListView)findViewById(R.id.list);
		 
		 
	     adapter = new CheckListAdapter(this,getResources().getStringArray(R.array.ton_einstellungen));
		 list.setAdapter(adapter);
	     list.setOnItemClickListener(new OnItemClickListener() {

	    	 @Override
	    	 public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
	    	 long arg3) {
	    	 // TODO Auto-generated method stub
	    	 CheckedTextView tv = (CheckedTextView)arg1;
	    	 if (tv.isChecked())
		        {
		            tv.setChecked(false);
		            if(tv.getText().equals("Ton")){
		            	sound=false;
		            }
		            if(tv.getText().equals("Vibration")){
		            	
		            	vibration=false;
		            }
		        }
		        else
		        {
		        	if(tv.getText().equals("Ton")){
		            	sound=true;
		            }
		        	if(tv.getText().equals("Vibration")){
		            	
		            	vibration=true;
		            }
		            tv.setChecked(true);
		        }
	    	 }
	    	        
	    	 });

	 
	}  
	    
	    
	
	
	
	
	
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_einstellungen_ton, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
	    switch (item.getItemId()) {
	        case android.R.id.home:
	            // app icon in action bar clicked; go home
	            Intent intent = new Intent(this, MainActivity.class);
	            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	            startActivity(intent);
	            return true;
	            
	        case R.id.openDayView:
	        	Intent oDV = new Intent(this, TagesViewActivity.class);
	        	startActivity(oDV);
	        	
	            
	        default:
	            return super.onOptionsItemSelected(item);
	    }
	}
	
	
	 /**
	  * Einstellungen best�tigen
	  * @param view Button welcher gedr�ckt wurde
	  */
	 public void ok(View view){
		 
		 save();
		 finish();	 }
	 
	 /**
	  * Einstellungen abbrechen
	  * @param view  Button welcher gedr�ckt wurde
	  */
	 public void abort(View view){
		 
		 finish();
	 }
	 /**
 	  * Einstellungen speichern
 	  */
	 public void save(){
		 
		 MainActivity.getProfil().getEinstellungen().setTon(sound);
		 MainActivity.getProfil().getEinstellungen().setVibration(vibration);
	 }
}
