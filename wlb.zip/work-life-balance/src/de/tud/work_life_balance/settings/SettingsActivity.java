package de.tud.work_life_balance.settings;

import java.util.ArrayList;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import de.tud.work_life_balance.MainActivity;
import de.tud.work_life_balance.R;
import de.tud.work_life_balance.TagesViewActivity;


/**
 * 
 * Diese Klasse ist eine Activity welche die Einstellungen verwaltet
 * 
 * @author Matthias Conrad
 *
 */

public class SettingsActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_einstellungen);

		final ActionBar actionBar = getActionBar();
		actionBar.setDisplayHomeAsUpEnabled(true);

		buildActivity();

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_einstellungen, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// app icon in action bar clicked; go home
			Intent intent = new Intent(this, MainActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent);
			return true;

		case R.id.openDayView:
			Intent oDV = new Intent(this, TagesViewActivity.class);
			startActivity(oDV);

		default:
			return super.onOptionsItemSelected(item);
		}
	}

	

	/**
	 * startet die activity wo man das profil bearbeiten kann
	 */
	private void startProfil() {

		startActivity(new Intent(
				this,
				de.tud.work_life_balance.settings.SettingsProfile.class));

	}

	/**
	 * startet die activity welche benachrichtigungseinstellungen beinhaltet
	 */
	private void startBenachrichtigung() {

		startActivity(new Intent(
				this,
				de.tud.work_life_balance.settings.SettingsNotificaiton.class));

	}

	/**
	 * startet die activity welche standortseinstellungen beinhaltet
	 */
	private void startStandort() {

		startActivity(new Intent(
				this,
				de.tud.work_life_balance.settings.SettingsLocation.class));

	}

	/**
	 * startet die activity welche toneinstellungen beinhaltet
	 */
	private void startTon() {

		startActivity(new Intent(this,
				de.tud.work_life_balance.settings.SettingsSound.class));

	}

	/**
	 *  Baut die Activity auf
	 */
	private void buildActivity() {

		ArrayList<SettingsListItem> menuePoints = new ArrayList<SettingsListItem>();

		menuePoints
				.add(new de.tud.work_life_balance.settings.SettingsListItem(
						getString(R.string.benachrichtigungen), null));
		
		menuePoints
				.add(new de.tud.work_life_balance.settings.SettingsListItem(
						getString(R.string.profil), null));
		menuePoints
				.add(new de.tud.work_life_balance.settings.SettingsListItem(
						getString(R.string.toene), null));
		menuePoints
				.add(new de.tud.work_life_balance.settings.SettingsListItem(
						getString(R.string.standort), null));

		final ListView menueList = (ListView) findViewById(R.id.listView1);

		menueList.setAdapter(new SettingsItemAdapter(this,
				R.layout.listitem, menuePoints));

		menueList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				switch (position) {

				

				case 1:

					startProfil();

					break;

				case 2:

					startTon();

					break;

				case 3:

					startStandort();

					break;

				default:
					startBenachrichtigung();

				}

			}

		});

	}

}
