package de.tud.work_life_balance.settings;

import android.graphics.drawable.Drawable;

/**
 * Diese Klasse repr�sentiert ein Listenelement welches in den Einstellungsactivities verwendet wird
 * 
 * @author Matthias Conrad
 *
 */
public class SettingsListItem {
	
    public String setting;
    public Drawable thumbnail;


    // TODO a Setter for the icon

    public SettingsListItem(String menue, Drawable thumbnail) {

    	this.thumbnail = thumbnail;
    	
        this.setting = menue;

    }
}
