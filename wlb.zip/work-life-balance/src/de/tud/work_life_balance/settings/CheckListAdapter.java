package de.tud.work_life_balance.settings;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckedTextView;
import de.tud.work_life_balance.MainActivity;
import de.tud.work_life_balance.R;


/**
 * Diese Klasse stellt eine Adapter her welcher Listenelemente mit checkbox verwaltet
 * 
 * @author Matthias Conrad
 *
 */
public class CheckListAdapter extends BaseAdapter {

		boolean checked;
		String[] items;
		Context acitvity;

		public CheckListAdapter(Context context, String[] item) {
		this.items = item;
		acitvity=context;
		}

		// @Override
		public View getView(int position, View convertView, ViewGroup parent) {
		View v = convertView;
		if (v == null) {
		LayoutInflater vi = (LayoutInflater) acitvity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		v = vi.inflate(R.layout.checkbox_listitem, null);
		} 
		CheckedTextView post = (CheckedTextView) v.findViewById(R.id.checkList);
		post.setText(items[position]);
		//einstellungen laden
		
		//lade benachrichtigung
		if(acitvity.getClass().equals(SettingsNotificaiton.class)){
			
		
		if(MainActivity.getProfil().getEinstellungen().isBenachrichtigung()){
			post.setChecked(true);
		}
		}
		//lade t�ne
		if(acitvity.getClass().equals(SettingsSound.class)){
			//ton
			
			if(post.getText().equals("Ton")){
				if(MainActivity.getProfil().getEinstellungen().isTon()){
					post.setChecked(true);
				}
			}
			//vibration
			if(post.getText().equals("Vibration")){
				if(MainActivity.getProfil().getEinstellungen().isVibration()){
					post.setChecked(true);
				}
			}
			
		}
		return v;
		}

		public int getCount() {
		return items.length;
		}

		public Object getItem(int position) {
		return position;
		}

		public long getItemId(int position) {
		return position;
		}
		}	
	

