package de.tud.work_life_balance.settings;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import de.tud.work_life_balance.MainActivity;
import de.tud.work_life_balance.R;
import de.tud.work_life_balance.TagesViewActivity;


/**
 * Diese Klasse baut eine Activity auf, welche �ber den Datenschutz informiert
 * 
 * @author Matthias Conrad
 *
 */
public class SettingsInfoPrivacyPolicy extends Activity {
	
	
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_einstellungen_info_datenschutz);
		final ActionBar actionBar = getActionBar();
		actionBar.setDisplayHomeAsUpEnabled(true);
		
		buildActivity();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(
				R.menu.activity_einstellungen_info_datenschutz, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
	    switch (item.getItemId()) {
	        case android.R.id.home:
	            // app icon in action bar clicked; go home
	            Intent intent = new Intent(this, MainActivity.class);
	            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	            startActivity(intent);
	            return true;
	            
	        case R.id.openDayView:
	        	Intent oDV = new Intent(this, TagesViewActivity.class);
	        	startActivity(oDV);
	        	
	            
	        default:
	            return super.onOptionsItemSelected(item);
	    }
	}
	public void buildActivity(){
		
		CheckBox check= (CheckBox)findViewById(R.id.datenschutz_checkbox);
		
		//laden
		check.setChecked(MainActivity.getProfil().getEinstellungen().isDatenfreigabe());
		
		//speichern
		check.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				// TODO Auto-generated method stub
				CheckBox check= (CheckBox)findViewById(R.id.datenschutz_checkbox);
				if(isChecked){
					
					check.setChecked(true);
					MainActivity.getProfil().getEinstellungen().setDatenfreigabe(true);
				}
				else{
					check.setChecked(false);
					MainActivity.getProfil().getEinstellungen().setDatenfreigabe(false);
				}
			}
		});
	}

	
}
