package de.tud.work_life_balance;

import java.util.ArrayList;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import de.tud.work_life_balance.diagrams.BarShape;

/**
 * Activity, die eine Uebersicht ueber das Gleichgewicht der vier Lebensbereiche
 * (Beruf, Kontakt, Koerper, Sinn) des Nutzers anzeigt.
 * <p>
 * Beim momentanen Stand (03.04.2013) zeigen die Balken nicht die tatsaechlichen
 * Werte an. Die Balken koennen aber schon, sobald eine Formel zur Errechnung
 * der Balance feststeht dazu programmiert werden ihre Groesse und Farbe zu
 * aendern.
 * 
 * @see BarShape
 * 
 */
public class TagesViewActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tages_view);

		final ActionBar actionBar = getActionBar();
		actionBar.setDisplayHomeAsUpEnabled(true);
		
		//initialisieren der Bardiagramms
		BarShape berufShape =  new BarShape(10);
		BarShape kontaktShape =  new BarShape(50);
		BarShape koerperShape =  new BarShape(46);
		BarShape sinnShape =  new BarShape(80);
		//Finden der 4 bereichssektoren im Layout
		LinearLayout beruf = (LinearLayout) findViewById(R.id.tagesViewGewicht1);
		LinearLayout kontakt = (LinearLayout) findViewById(R.id.tagesViewGewicht2);
		LinearLayout koerper = (LinearLayout) findViewById(R.id.tagesViewGewicht3);
		LinearLayout sinn = (LinearLayout) findViewById(R.id.tagesViewGewicht4);
		ImageView imageOne = (ImageView) findViewById(R.id.gewicht1);
		// beruf.setBackground(berufShape);
		beruf.setBackgroundDrawable(berufShape);
		kontakt.setBackgroundDrawable(berufShape);
		koerper.setBackgroundDrawable(berufShape);
		sinn.setBackgroundDrawable(berufShape);
		// beruf.addView(berufDiagram);
		// kontakt.addView(kontaktDiagram);
		// koerper.addView(koerperDiagram);
		// sinn.addView(sinnDiagram);

		fillList();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_tages_view, menu);
		return true;
	}

	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// app icon in action bar clicked; go home
			Intent intent = new Intent(this, MainActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent);
			return true;

		default:
			return super.onOptionsItemSelected(item);
		}
	}

	private void fillList() {

		ArrayList<ListItem> dayViewList = new ArrayList<ListItem>();

		dayViewList.add(new ListItem("Neue Erkenntnisse", null));
		dayViewList.add(new ListItem("10 Tips zur Selbstorganisation", null));
		dayViewList.add(new ListItem("Priorisierungsmechanismen", null));
		dayViewList.add(new ListItem("Unterschiede Männer und Frauen", null));
		dayViewList.add(new ListItem("Genetische disposition", null));

		final ListView tagesListe = (ListView) findViewById(R.id.tagesViewList);

		tagesListe.setAdapter(new ListItemAdapter(this, R.layout.listitem,
				dayViewList));

		tagesListe.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(final AdapterView<?> arg0, final View arg1,
					final int arg2, final long arg3) {
				Util.showUnimplementedToast(TagesViewActivity.this);
			}
		});

	}

}
