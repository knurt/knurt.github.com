package de.tud.work_life_balance.lokalisierung;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Diese Klasse verpackt SQL-Datenbank-Zugriffe um einen einfacheren Zugriff auf
 * die Datenbank mit den Ortsdaten zu ermoeglichen.
 * 
 */
public class LocationDatabase {
	private static final String DATABASE_NAME = "wlb_database";
	private static final String DATABASE_TABLE = "locations_table";
	private static final int DATABASE_VERSION = 1;

	private static final String DATABASE_CREATE = "create table "
			+ DATABASE_TABLE + " (_id integer primary key autoincrement, "
			+ "latitude real, longitude real, placename text not null);";

	private final Context context;

	private DatabaseHelper DBHelper;
	private SQLiteDatabase db;

	private static final String[] columns = new String[] { "_id", "latitude",
			"longitude", "placename" };

	public LocationDatabase(Context ctx) {
		this.context = ctx;
		DBHelper = new DatabaseHelper(context);
	}

	private static class DatabaseHelper extends SQLiteOpenHelper {
		DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(DATABASE_CREATE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w("LocationDatabase", "Upgrading database from version "
					+ oldVersion + " to " + newVersion
					+ ", which will destroy all old data");
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
			onCreate(db);
		}
	}

	public LocationDatabase open() throws SQLException {
		db = DBHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		DBHelper.close();
	}

	public long insertLocation(double latitude, double longitude,
			String placeName) {
		ContentValues values = new ContentValues();
		values.put("latitude", latitude);
		values.put("longitude", longitude);
		values.put("placename", placeName);
		return db.insert(DATABASE_TABLE, null, values);
	}

	public boolean deleteLocation(long rowId) {
		return db.delete(DATABASE_TABLE, "_id=" + rowId, null) > 0;
	}

	public Cursor getAllLocations() {
		return db.query(DATABASE_TABLE, columns, null, null, null, null, null);
	}

	public Cursor getLocation(long rowId) throws SQLException {
		Cursor cursor = db.query(true, DATABASE_TABLE, columns, "_id=" + rowId,
				null, null, null, null, null);
		if (cursor != null) {
			cursor.moveToFirst();
		}
		return cursor;
	}

	public boolean updateLocation(long rowId, double latitude,
			double longitude, String placeName) {
		ContentValues values = new ContentValues();
		values.put("latitude", latitude);
		values.put("longitude", longitude);
		values.put("placename", placeName);
		return db.update(DATABASE_TABLE, values, "_id=" + rowId, null) > 0;
	}
}
