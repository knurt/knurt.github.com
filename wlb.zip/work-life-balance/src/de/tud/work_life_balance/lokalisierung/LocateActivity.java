package de.tud.work_life_balance.lokalisierung;

import java.util.ArrayList;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import de.tud.work_life_balance.MainActivity;
import de.tud.work_life_balance.R;
import de.tud.work_life_balance.TagesViewActivity;
import de.tud.work_life_balance.lokalisierung.LocationList.Element;

/**
 * Diese Klasse ist eine Activity, in der der Nutzer Koordinaten, an denen er
 * sich befindet Namen geben kann und in der angezeigt wird, wie weit entfernt
 * er sich von den gespeicherten Orten befindet.
 */
public class LocateActivity extends Activity implements LocationListener {

	private LocationManager locManager;
	private TextView tvLocation;
	private Button bDebug;
	private ListView lvLocationList;
	private EditText etLocationName;

	private LocationList locationList;
	private LocationDatabase database;
	private double currentLatitude, currentLongitude;
	// TODO Die eigene aktuelle Position wird momentan (03.03.1013) redundant
	// gespeichert in LocateActivity und LocationList
	private ArrayAdapter<LocationList.Element> adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.locate_layout);

		final ActionBar actionBar = getActionBar();
		actionBar.setDisplayHomeAsUpEnabled(true);

		bDebug = (Button) findViewById(R.id.bDebug);
		tvLocation = (TextView) findViewById(R.id.tvLocation);
		etLocationName = (EditText) findViewById(R.id.etLocationName);
		lvLocationList = (ListView) findViewById(R.id.lvLocationList);

		locationList = new LocationList();
		database = new LocationDatabase(this);

		currentLatitude = -1;
		currentLongitude = -1;

		database.open();
		Cursor c = database.getAllLocations();
		if (c != null) {
			c.moveToFirst();
			while (!c.isAfterLast()) {
				locationList
						.add(c.getDouble(1), c.getDouble(2), c.getString(3));
				c.moveToNext();
			}
		}
		database.close();

		adapter = new ArrayAdapter<LocationList.Element>(this,
				android.R.layout.simple_list_item_1, locationList);
		lvLocationList.setAdapter(adapter);

		bDebug.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Log.e("LocateActivity",
						"locationList = " + locationList.toString());
				String text = "";
				for (LocationList.Element e : locationList) {
					text += e.locationName + " " + e.latitude + "/"
							+ e.longitude + " -> " + e.distance + " || ";
				}
				Log.e("LocateActivity", text);
			}
		});

		etLocationName.setEnabled(false);
		etLocationName.setOnEditorActionListener(new OnEditorActionListener() {
			@Override
			public boolean onEditorAction(TextView v, int actionId,
					KeyEvent event) {
				boolean handled = false;
				if (actionId == EditorInfo.IME_ACTION_SEND) {
					String locationName = v.getText().toString();
					locationList.add(currentLatitude, currentLongitude,
							locationName);
					database.open();
					database.insertLocation(currentLatitude, currentLongitude,
							locationName);
					database.close();
					adapter.notifyDataSetChanged();
					v.setText("");
					v.clearFocus();
					handled = true;
				}
				return handled;
			}
		});

		locManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		// As long as this Activity is active (between onCreate and onStop) it
		// will query GPS every 500 milliseconds.
		locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000,
				0, this);
		if (!locManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
			tvLocation.setText("GPS geht nicht.");
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_locate, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// App-Icon angeklickt: Zurück in den Hauptbildschirm
			Intent intent = new Intent(this, MainActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent);
			return true;

		case R.id.openDayView:
			Intent oDV = new Intent(this, TagesViewActivity.class);
			startActivity(oDV);

		default:
			return super.onOptionsItemSelected(item);
		}
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onLocationChanged(Location location) {
		Log.d("LocateActivity", "\n~~~~~~~~~~~~~~~~~~~~~\nLocation changed\n");
		etLocationName.setEnabled(true);

		currentLatitude = location.getLatitude();
		currentLongitude = location.getLongitude();
		Log.d("LocateActivity", "current Lat/Lon: " + currentLatitude + " / "
				+ currentLongitude);
		locationList.setSelfCoordinates(currentLatitude, currentLongitude);
		adapter.notifyDataSetChanged();
		tvLocation.setText(String.format("%f.4 / %f.4", currentLatitude,
				currentLongitude));
	}

	@Override
	protected void onStop() {
		super.onStop();
		ArrayList<String> orteArray = new ArrayList<String>();
		for (Element elem : locationList) {
			orteArray.add(elem.locationName);
		}
		MainActivity.getProfil().setOrte(orteArray);
		locManager.removeUpdates(this);
	}
}