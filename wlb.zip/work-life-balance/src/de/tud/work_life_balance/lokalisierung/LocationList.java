package de.tud.work_life_balance.lokalisierung;

import java.util.ArrayList;
import java.util.Collections;

import android.location.Location;
import de.tud.work_life_balance.lokalisierung.LocationList.Element;

/**
 * Diese Klasse beschreibt eine Liste von {@link Element}en, die Datensaetze aus
 * Ortsnamen, Koordinaten und Entfernungen darstellen.
 * <p>
 * Diese Klasse wird in der {@link LocateActivity} verwendet um mit einem
 * {@link ArrayAdapter} eine {@link ListView} mit Inhalten zu fuellen.
 * 
 */
public class LocationList extends ArrayList<Element> {
	private static final long serialVersionUID = 1L;

	private double selfLat, selfLon;

	public LocationList() {
		super();
		selfLat = -1;
		selfLon = -1;
	}

	/**
	 * Sets the reference coordinates to the given new coordinates. In the
	 * process all stored location elements are recalculated and sorted.
	 * 
	 * @param latitude
	 * @param longitude
	 */
	public void setSelfCoordinates(double latitude, double longitude) {
		selfLat = latitude;
		selfLon = longitude;
		updateDistances();
	}

	/**
	 * Calculates the distance to the given coordinates for each element in the
	 * list and updates them accordingly.
	 * 
	 * @param latitude
	 * @param longitude
	 */
	private void updateDistances() {
		for (Element e : this) {
			float[] dist = new float[1];
			Location.distanceBetween(e.latitude, e.longitude, selfLat, selfLon,
					dist);
			e.distance = dist[0];
			e.currentInformation = true;
		}
		sort();
	}

	public void sort() {
		Collections.sort(this);
	}

	@Override
	public boolean add(Element e) {
		boolean success = super.add(e);
		sort();
		// notification

		return success;
	}

	public boolean add(double longitude, double latitude, String locationName) {
		float[] dist = new float[1];
		boolean currentInformation = (selfLat != -1 && selfLon != -1);
		Location.distanceBetween(latitude, longitude, selfLat, selfLon, dist);
		return add(new Element(longitude, latitude, locationName, dist[0],
				currentInformation));
	}

	/**
	 * Element beschreibt den Typ der Elemente, die in der {@link LocationList}
	 * gespeichert sind.<br>
	 * Besteht aus Laengen- und Breitengrad, den Namen des Orts und der Distanz
	 * zum aktuellen Aufenthaltsort.
	 * 
	 */
	public class Element implements Comparable<Element> {
		double latitude, longitude;
		String locationName;
		float distance;
		boolean currentInformation;

		public Element(double latitude, double longitude, String locationName,
				float distance, boolean currentInformation) {
			this.latitude = latitude;
			this.longitude = longitude;
			this.locationName = locationName;
			this.distance = distance;
			this.currentInformation = currentInformation;
		}

		@Override
		public int compareTo(Element another) {
			if (distance < another.distance)
				return -1;
			else
				return 1;
		}

		@Override
		public String toString() {
			if (currentInformation) {
				return String.format("%s :  %.0fm", locationName, distance);
			} else {
				return String.format("%s", locationName);
			}
		}

	}
}
