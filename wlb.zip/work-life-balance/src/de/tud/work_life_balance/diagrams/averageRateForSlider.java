package de.tud.work_life_balance.diagrams;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;

public class averageRateForSlider extends Drawable{

	private ShapeDrawable mDrawable;
	private int x = 10;
	private int y = 10;
	private int width = 5;
	private int height = 100;

	@SuppressWarnings("deprecation")
	public averageRateForSlider() {
		
		mDrawable = new ShapeDrawable();
		
	    mDrawable.getPaint().setColor(0xff74AC23);
	    mDrawable.setBounds(x, y, x+80, y+80);
	    
	}
	
	
	
	public void setX (int x){
		this.x = x;
	}
	
	public void setY (int y){
		this.y = y;
		
	}
	
	public void setWidth (int width){
		this.width = width;
	}
	
	public void setHeight(int height){
		this.height = height;
	}

	@Override
	public void draw(Canvas canvas) {
		mDrawable.draw(canvas);
		
	}

	@Override
	public int getOpacity() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setAlpha(int alpha) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setColorFilter(ColorFilter cf) {
		// TODO Auto-generated method stub
		
	}

}
