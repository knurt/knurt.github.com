package de.tud.work_life_balance.diagrams;

import android.R.color;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;

public class BarShape extends Drawable{
	
	private final int heighOfGrafic = 98;
	private ShapeDrawable balken;
	private ShapeDrawable mittellinie;
	private ShapeDrawable gestrichelteLinienOben;
	private ShapeDrawable gestrichelteLinienUnten;
	//anfang des Balkens von links
	private int xCoordinateOfShape = 0;
	//Anfang des balkens von oben
	private int yCoordinateOfShape = 5;
	/* Breite des Balkens
	 * der wert muss >xCoordinateOfShape sein
	 */
	private int widthOfShape = xCoordinateOfShape + 88;
	/*Höhe des Balkens
	 * Der Balken wird links oben angefangen zu zeichnen. der werd heightOfShape ist also der wert
	 * wie weit nach unten der Balken wächst
	 */
	
	private int heightOfShape = yCoordinateOfShape + 46;
	private int xOfLine = xCoordinateOfShape;
	private int yOfLine = heighOfGrafic/2;
	private int widthOfLine = xOfLine + 88;
	private int heightofLine = yOfLine + 1;
	private int x = 0;
	private int y = 5;
	private int width = 5;
	private int height = 100;
	private int yOfObereLinie = yOfLine-4;
	private int yOfUnterelinie = yOfLine+4;
	int auslastung = 80;

	public BarShape() {
		
		balken = new ShapeDrawable(new RectShape());
	    balken.setBounds(xCoordinateOfShape, yCoordinateOfShape+auslastung, widthOfShape,heighOfGrafic);
	    balken.getPaint().setColor(0xff74AC23);
	    mittellinie = new ShapeDrawable(new RectShape());
	    mittellinie.getPaint().setColor(0xffffffff);
	    mittellinie.setBounds(xOfLine, yOfLine, widthOfLine, heightofLine);
	    setGestrichelteLinien();
	    setColor(auslastung);
	}
	
	public int getAuslastung() {
		return auslastung;
	}

	public void setAuslastung(int auslastung) {
		this.auslastung = auslastung;
	}

	public BarShape(int auslastung){
		balken = new ShapeDrawable(new RectShape());
	    balken.setBounds(xCoordinateOfShape, yCoordinateOfShape+auslastung, widthOfShape,heighOfGrafic);
	    mittellinie = new ShapeDrawable(new RectShape());
	    mittellinie.getPaint().setColor(0xffffffff);
	    mittellinie.setBounds(xOfLine, yOfLine, widthOfLine, heightofLine);
	    setGestrichelteLinien();
	    setColor(auslastung);
	   
		
	}
	
	
	
	private void setGestrichelteLinien() {
	//	for(int i =0; i<widthOfLine; i= i+5){
		gestrichelteLinienOben = new ShapeDrawable(new RectShape());
		gestrichelteLinienUnten = new ShapeDrawable(new RectShape());
		gestrichelteLinienOben.setBounds(xOfLine, yOfObereLinie, widthOfLine, yOfObereLinie+1);
		gestrichelteLinienUnten.setBounds(xOfLine, yOfUnterelinie, widthOfLine, yOfUnterelinie+1);
		gestrichelteLinienOben.getPaint().setColor(0xffffffff);
		gestrichelteLinienUnten.getPaint().setColor(0xffffffff);
		//}
	}

	private void setColor(int auslastung) {
		if(auslastung == 0){
			balken.getPaint().setColor(0xffffffff);
		}
		else{
		
		if(auslastung < yOfObereLinie || auslastung > yOfUnterelinie){
			balken.getPaint().setColor(0xffff0000);
		//	balken.getPaint().setColor(0xFF0000);
		}
		else{
			balken.getPaint().setColor(0xff74AC23);
			
		}}
		
	}



	public void setX (int x){
		this.x = x;
	}
	
	public void setY (int y){
		this.y = y;
		
	}
	
	public void setWidth (int width){
		this.width = width;
	}
	
	public void setHeight(int height){
		this.height = height;
	}

	@Override
	public void draw(Canvas canvas) {
		balken.draw(canvas);
		mittellinie.draw(canvas);
		gestrichelteLinienOben.draw(canvas);
		gestrichelteLinienUnten.draw(canvas);
		
		
	}

	@Override
	public int getOpacity() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setAlpha(int alpha) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setColorFilter(ColorFilter cf) {
		// TODO Auto-generated method stub
		
	}
	

}
