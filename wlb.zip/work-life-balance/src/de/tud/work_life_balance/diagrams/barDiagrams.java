package de.tud.work_life_balance.diagrams;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import android.view.View;

public class barDiagrams extends View{
	
	private ShapeDrawable mDrawable;
	private int x = 10;
	private int y = 10;
	private int width = 5;
	private int height = 100;

	public barDiagrams(Context context) {
		super(context);
		
		mDrawable = new ShapeDrawable(new RectShape());
	    mDrawable.getPaint().setColor(0xff74AC23);
	    mDrawable.setBounds(x, y, x+30, y+88);
	}
	
	 protected void onDraw(Canvas canvas) {
		    mDrawable.draw(canvas);
	 }
	
	
	public void setX (int x){
		this.x = x;
	}
	
	public void setY (int y){
		this.y = y;
		
	}
	
	public void setWidth (int width){
		this.width = width;
	}
	
	public void setHeight(int height){
		this.height = height;
	}

}
