package de.tud.work_life_balance.lebensvision;

public class koerper extends lVisionen {

	public koerper() {
		super();
		// TODO Auto-generated constructor stub
	}
}
