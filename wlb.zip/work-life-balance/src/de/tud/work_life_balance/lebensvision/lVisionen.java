package de.tud.work_life_balance.lebensvision;

public class lVisionen {
	
	private int weight = 0;
	private int priority = 1;
	
	public lVisionen() {
		super();
	}

	
	
	//weight soll den prozentualen anteil der 4 Abteilungen darstellen.
	//dieser wird mit prioritaet multipliziert unm eine genauere Gewichtung zu bekommen.
	public int getWeight(){
		return weight;
	}
	
	public void setWeight(int addWeight){
	weight = addWeight;
	
	}
	
	//Priority muss ein wert zwischen 1 und 5 sein. 
	public boolean setPriority(int addPriority){
		if(addPriority <5 && addPriority > 0){
		priority = addPriority;
		return true;
	}
		else{
			return false;
		}
	}
	
	public int getPriority(){
		return priority;
	}
	
}
