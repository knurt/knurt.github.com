package de.tud.work_life_balance.lebensvision.balanceAlgo;

import de.tud.work_life_balance.lebensvision.koerper;
import de.tud.work_life_balance.lebensvision.kontakt;
import de.tud.work_life_balance.lebensvision.leistungArbeit;
import de.tud.work_life_balance.lebensvision.sinn;

public class bAlgo {

	koerper k;
	kontakt c;
	leistungArbeit l;
	sinn s;

	public bAlgo(koerper k, kontakt c, leistungArbeit l, sinn s) {
		this.k = k;
		this.c = c;
		this.l = l;
		this.s = s;
	}

	public void AlgoOhnePriorisierung(koerper k, kontakt c, leistungArbeit l, sinn s) {
		// 100 Prozent berechnen
		int sumOfAllWeights = k.getWeight() + c.getWeight() + l.getWeight() + s.getWeight();

		// Berechnen der prozentualen Anteile
		int weightOfkoerper = (int) ((k.getWeight() * 100) / sumOfAllWeights);
		int weightOfkontakts = (int) ((c.getWeight() * 100) / sumOfAllWeights);
		int weightOfleistungArbeit = (int) ((l.getWeight() * 100) / sumOfAllWeights);
		int weightOfsinn = (int) ((s.getWeight() * 100) / sumOfAllWeights);
	}

	public void AlgoMitPriorisierung(koerper k, kontakt c, leistungArbeit l, sinn s) {
		// 100 Prozent berechnen
		int sumOfAllWeights = (k.getWeight() + c.getWeight() + l.getWeight() + s.getWeight());
		int sumPlusPrio = sumOfAllWeights * k.getPriority() * c.getPriority() * l.getPriority() * s.getPriority();

		// Berechnen der prozentualen Anteile
		int weightOfkoerper = (int) (((k.getWeight() * 100) / sumOfAllWeights) * k.getPriority());
		int weightOfkontakts = (int) (((c.getWeight() * 100) / sumOfAllWeights) * c.getPriority());
		int weightOfleistungArbeit = (int) (((l.getWeight() * 100) / sumOfAllWeights) * l.getPriority());
		int weightOfsinn = (int) (((s.getWeight() * 100) / sumOfAllWeights) * s.getPriority());
	}

}
