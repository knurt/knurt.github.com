package de.tud.work_life_balance.lebensvision;

public class kontakt extends lVisionen{
	
	public kontakt() {
		super();
		// TODO Auto-generated constructor stub
	}

}
