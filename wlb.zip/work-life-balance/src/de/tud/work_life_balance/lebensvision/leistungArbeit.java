package de.tud.work_life_balance.lebensvision;

public class leistungArbeit extends lVisionen{

	public leistungArbeit() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
