package de.tud.work_life_balance.lebensvision;

public class sinn extends lVisionen{

	public sinn() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
