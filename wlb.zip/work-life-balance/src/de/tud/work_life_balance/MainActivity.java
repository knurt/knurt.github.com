package de.tud.work_life_balance;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import de.tud.work_life_balance.lokalisierung.LocateActivity;
import de.tud.work_life_balance.profil.Profile;
import de.tud.work_life_balance.settings.SettingsInfo;
import de.tud.work_life_balance.settings.SettingsInfoInfotour;

/**
 * Haupt-Activity, die beim Start der App angezeigt wird. Bei ersten Starten der
 * App - wenn noch kein Benutzerprofil mit seinen persoenlichen Daten angelegt
 * ist, wird er gefragt, ob er die Info-Tour sehen moechte.
 * <p>
 * Danach wird ein Menue mit Abzweigungen zu den verschiedenen Funktionalitaeten
 * der App angezeigt.
 * 
 * @see SettingsInfoInfotour
 * 
 */
public class MainActivity extends Activity {

	/**
	 * Dialogfenster, dass nochmal fragt, ob das Programm wirklich beendet
	 * werden soll.
	 */
	private Dialog dlgCloseApp;

	/**
	 * Ein Profile ist eine serialisierbare Klasse, in der alle Daten eines
	 * Nutzers, wie Termine und Anwendungseinstellungen gesichert sind.
	 * 
	 * In der aktuellen Version wird nur ein Profil gespeichert, es sind aber
	 * auch Szenarien denkbar, in denen mehrere Profile gespeichert werden
	 * können.
	 * 
	 * @see Profile
	 */
	private static Profile profile;

	/**
	 * Verzeichnis, in dem sich das Profil befindet
	 */
	File profilePath = new File(Util.getSDCardPath());

	/**
	 * Profil-Datei
	 */
	File profileFile = new File(Util.getSDCardPath() + "profil");

	@Override
	public void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		Log.d("MainActivity",
				profilePath.exists() + " // " + profileFile.exists());

		Util.setupActionbar(this);

		loadProfil();
		// wegen testen
		fillList();

		// einmaliges starten der Infotour
		if (profile.isInfoTourStarten()) {
			setContentView(R.layout.activity_einstellungen_info_infotour);
			profile.setInfoTourStarten(false);
		}
	}

	/**
	 * Wenn die App endgültig beendet wird - das heißt in den
	 * "Destroyed"-Zustand des Activity-Life-Cycles übergeht, wird das Profil im
	 * Dateisystem gesichert.
	 */
	@Override
	protected void onDestroy() {
		saveProfil();
		super.onDestroy();
	}

	/**
	 * Callback-Methode, die darauf reagiert, dass das Icon mit der Pin-Nadel
	 * gedrückt wurde.
	 * <p>
	 * Startet die Activity mit der Lokalisierungs-Funktion.
	 * 
	 * @see LocateActivity
	 * @param view
	 *            View-Objekt, das angeklickt wurde
	 */
	public void onPinClick(final View view) {
		Intent intent = new Intent(this, LocateActivity.class);
		startActivity(intent);
	}

	/**
	 * Callback-Methode, die darauf reagiert, dass das Icon mit dem Info-I
	 * gedr&uum;kt wurde.
	 * <p>
	 * Startet eine Activity mit Informationen über die App.
	 * 
	 * @see SettingsInfo
	 * @param view
	 *            View-Objekt, das angeklickt wurde
	 */
	public final void onInfoClick(final View view) {
		Intent intent = new Intent(this, SettingsInfo.class);
		startActivity(intent);
	}

	/**
	 * Callback-Methode, die darauf reagiert, dass das Icon mit dem
	 * Einstellungssymbol gedr&uum;kt wurde.
	 * <p>
	 * Startet das Einstellungs-Menü.
	 * 
	 * @param view
	 *            View-Objekt, das angeklickt wurde
	 */
	public void onSettingsClick(final View view) {
		Intent intent = new Intent(this,
				de.tud.work_life_balance.settings.SettingsActivity.class);
		startActivity(intent);
	}

	/**
	 * Callback-Methode, die darauf reagiert, dass das Icon mit dem Stift
	 * gedr&uum;kt wurde.
	 * <p>
	 * Startet die "NavTabSwipe"-Demo.
	 * 
	 * @param view
	 *            View-Objekt, das angeklickt wurde
	 */
	public void onPenClick(final View view) {
		Intent intent = new Intent(this,
				de.tud.work_life_balance.mediaCenter.MediaCenter.class);
		startActivity(intent);
	}

	/**
	 * Callback-Methode, die darauf reagiert, dass das Icon mit dem Kalender
	 * gedr&uum;kt wurde.
	 * <p>
	 * Startet den Kalender.
	 * 
	 * @param view
	 *            View-Objekt, das angeklickt wurde
	 */
	public void onCalendarClick(final View view) {
		Intent intent = new Intent(
				this,
				de.tud.work_life_balance.calendar.CalendarOverviewActivity.class);
		startActivity(intent);
	}

	/**
	 * Callback-Methode, die darauf reagiert, dass das Icon mit dem Joystick
	 * gedr&uum;kt wurde. Hat im Moment keine Funktionalität, was durch eine
	 * Nachricht angezeigt wird.
	 * 
	 * @param view
	 *            View-Objekt, das angeklickt wurde
	 * 
	 */
	public void onJoystickClick(final View view) {
		Util.showUnimplementedToast(this);
	}

	/**
	 * Wenn der entsprechende Button gecklickt wurde, wird die Infotour
	 * gestartet.
	 * 
	 * @param view
	 *            View-Objekt, das angeklickt wurde
	 */
	public void onStartInfotourClick(View view) {
		startActivity(new Intent(this, SettingsInfoInfotour.class));
		setContentView(R.layout.activity_main);
		Util.setupActionbar(this);
		fillList();
	}

	/**
	 * Wenn der entsprechende Button gecklickt wurde, wird die Infotour
	 * übersprungen.
	 * 
	 * @param view
	 *            View-Objekt, das angeklickt wurde
	 */
	public void onNoInfotourClick(View view) {
		setContentView(R.layout.activity_main);
		Util.setupActionbar(this);
		fillList();
	}

	/**
	 * Befüllt die Liste unterhalb der Modulübersicht mit Ersatz-Inhalten.
	 */
	private void fillList() {

		ArrayList<ListItem> newsList = new ArrayList<ListItem>();

		// Platzhalter Texte:
		String[] exampleList = getResources().getStringArray(
				R.array.example_list);
		for (int i = 0; i < exampleList.length; ++i) {
			newsList.add(new ListItem(exampleList[i], null));
		}

		final ListView news = (ListView) findViewById(R.id.listOfNews);

		news.setAdapter(new ListItemAdapter(this, R.layout.listitem, newsList));

		news.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(final AdapterView<?> arg0, final View arg1,
					final int arg2, final long arg3) {
				Util.showUnimplementedToast(MainActivity.this);
			}
		});
	}

	/**
	 * Serialisiert das Profil aus der MainActivity und sichert es auf dem
	 * Dateisystem.
	 */
	private void saveProfil() {

		profileFile.delete();
		FileOutputStream fileOpStream;
		try {
			profilePath.mkdirs();
			fileOpStream = new FileOutputStream(profileFile, true);
			ObjectOutputStream oos = new ObjectOutputStream(fileOpStream);
			oos.writeObject(profile);
			oos.close();
		} catch (FileNotFoundException e) {
			Util.showToast(this, getString(R.string.profile_couldnt_be_saved));
			Log.e("MainActivity", "Couldn't save profile data because file \""
					+ profileFile + "\" couldn't be found.", e);
		} catch (IOException e) {
			Util.showToast(this, getString(R.string.profile_couldnt_be_saved));
			Log.e("MainActivity",
					"Couldn't save profile data because of IOException.", e);
		}
	}

	/**
	 * Lädt das serialisierte Profil aus dem Dateisystem, falls die Datei
	 * existiert. Ansonsten wird ein neues Profil angelegt.
	 */
	private void loadProfil() {
		// Wenn das Profil nicht existiert
		// -> erstell es
		// Wenn das Profil existiert
		// -> lade es
		Log.d("MainActivity", "asfdasfd");

		if (!profileFile.exists()) {
			profile = new Profile();
		} else {
			try {
				ObjectInputStream o = new ObjectInputStream(
						new FileInputStream(profileFile));
				profile = (Profile) o.readObject();
				o.close();
			} catch (IOException e) {
				Log.e("MainActivity", e.getMessage(), e);
			} catch (ClassNotFoundException e) {
				Log.e("MainActivity", e.getMessage(), e);
			}
		}

		assert profile != null;
	}

	/**
	 * Das Profil ist zentrale Sammlung, in der alle relevanten Daten eines
	 * Benutzers zusammengefasst sind.
	 * 
	 * @return Gibt das Profil des Nutzers zurück.
	 */
	public static Profile getProfil() {
		return profile;
	}

	//
	// /**
	// * @param profil
	// * the profil to set
	// */
	// public static void setProfil(Profile profil) {
	// MainActivity.profile = profil;
	// }

	@Override
	public boolean onKeyDown(final int keyCode, KeyEvent event) {

		if (keyCode == KeyEvent.KEYCODE_BACK) {
			dlgCloseApp = new Dialog(this);
			dlgCloseApp.setTitle(R.string.confirm_end_program);
			dlgCloseApp.setContentView(R.layout.termin_abbrechen);
			dlgCloseApp.show();

			final Button btnYes = (Button) dlgCloseApp
					.findViewById(R.id.termin_abbrechen_ja_button);
			final Button btnNo = (Button) dlgCloseApp
					.findViewById(R.id.termin_abbrechen_nein_button);

			btnYes.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					dlgCloseApp.dismiss();
					saveProfil();
					finish();
				}
			});

			btnNo.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					dlgCloseApp.dismiss();
				}
			});

			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

}
