package de.tud.work_life_balance.erweiterungen;

import java.util.ArrayList;

public interface sucheNachErweiterungen {
	
	
	/** Die methode sucheErweiterungsPfade() sucht indem Ordner Erweiterungen anch den Erweiterungen und gibt den Pfad zu
	 * allen Unterordnern des Erweiterungsordners an.
	 * 
	 * @return ArrayList<String> 
	 */
	public ArrayList<String> sucheErweiterungsPfade();
	
	/** Die Methode addErweiterung() bindet die Erweiterungen in die bestehende App ein
	 * 
	 */
	public void addErweiterung();
	
	
	

}
