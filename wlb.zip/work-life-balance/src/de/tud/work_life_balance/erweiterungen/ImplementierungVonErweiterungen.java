package de.tud.work_life_balance.erweiterungen;

public interface ImplementierungVonErweiterungen {

}
