package de.tud.work_life_balance;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

/**
 * Diese Klasse kann als Super-Klasse fuer einige Activities in der WLB-App
 * genutzt werden, falls diese die Standart-Actionbar besitzen, mit einem Button
 * links, der zur {@link MainActivity} fuert und einen Button rechts, der zur
 * {@link TagesViewActivity} fuert.
 * <p>
 * Wird die Klasse vererbt, muss das Verhalten fuer diese beiden Menuepunkte
 * nicht mehr extra definiert werden. 
 *
 */
public abstract class WLBActivity extends Activity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {

		case R.id.openDayView:
			Intent oDV = new Intent(this, TagesViewActivity.class);
			startActivity(oDV);

		default:
			return super.onOptionsItemSelected(item);
		}
	}

}
