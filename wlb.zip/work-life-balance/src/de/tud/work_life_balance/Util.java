package de.tud.work_life_balance;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Diese Klasse enth&auml;lt einige Methoden, die unabhängig von irgendwelchen
 * Objekten sind und in verschiedenen Klassen verwendet werden.
 * <p>
 * "Util" kann nicht instanziiert werden und keine Klasse kann von ihr erben.
 * 
 */
public final class Util {

	/**
	 * Der Konstruktor ist als "private" deklariert, da die Klasse nur "static"
	 * Methoden enthält und nicht zum instanziieren geeignet ist.
	 */
	private Util() {
	}
	
	public static String getSDCardPath() {
		return "/sdcard/WLB/";
	}

	/**
	 * Blendet kurz eine Nachricht (Toast) "Noch nicht eingebaut" ein.
	 *
	 * @param activity Activity auf der der "Toast" angezeigt werden soll
	 */
	public static void showUnimplementedToast(final Activity activity) {
		Context context = activity.getApplicationContext();
		Resources res = activity.getResources();
		CharSequence text = res.getString(R.string.noch_nicht_eingebaut);
		int duration = Toast.LENGTH_SHORT;

		Toast toast = Toast.makeText(context, text, duration);
		toast.show();
	}
	
	/**
	 * Blendet kurz eine Nachricht (Toast) mit einer Meldung ein.
	 * Kann zum Beispiel f&uuml;r Fehlermeldungen verwendet werden.
	 *
	 * @param activity Activity auf der der "Toast" angezeigt werden soll
	 */
	public static void showToast(final Activity activity, String message) {
		Context context = activity.getApplicationContext();
		Resources res = activity.getResources();
		int duration = Toast.LENGTH_SHORT;

		Toast toast = Toast.makeText(context, message, duration);
		toast.show();
	}

	/**
	 * TODO .
	 * 
	 * @param caller
	 *            bla
	 */
	public static void setupActionbar(final Activity caller) {
		Button actionbarHome = (Button) caller.findViewById(R.id.actionbarHome);
		Button actionbarFunk = (Button) caller.findViewById(R.id.actionbarFunk);
		// Button actionbar_funk2 = (Button)findViewById(R.id.actionbarFunk2);
		final TextView actionbar_title = (TextView) caller.findViewById(R.id.actionbarTxt);
		actionbarFunk.setBackgroundResource(android.R.drawable.ic_menu_share);
		// actionbar_funk2.setBackgroundResource(android.R.drawable.ic_menu_preferences);

		actionbar_title.setText("Work-Life-Balance");
		actionbarFunk.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent oDV = new Intent(caller, TagesViewActivity.class);
				caller.startActivity(oDV);
			}
		});

		actionbarHome.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// Kein Zur�ck-Knopf in der MainActivity.
				if (!(caller instanceof MainActivity)) {
					caller.finish();
				}
			}
		});
	}
}
