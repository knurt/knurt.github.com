package de.tud.work_life_balance.mediaCenter.MediaPages;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import de.tud.work_life_balance.MainActivity;
import de.tud.work_life_balance.R;
import de.tud.work_life_balance.TagesViewActivity;

public class Entspannung extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_entspannung);
		final ActionBar actionBar = getActionBar();
		actionBar.setDisplayHomeAsUpEnabled(true);

		
		TextView tv = (TextView) findViewById(R.id.entspannungstext);
			tv.setText("Dieses Modul hilft Ihnen, Entspannungsphasen in Ihren Alltag zu integrieren. Den bei Stress bereitet sich der Körper auf Flucht oder Kampf vor. Das Herz rast, die Muskeln werden angespannt, Verdauung und Stoffwechsel kommen durcheinander, der Schlaf wird gestört. Die produzierten Stresshormone ermöglichen Höchstleistungen, sie werden durch die körperliche Aktivität abgebaut. Fehlt die Bewegung, werden Körper und Psyche belastet. Entspannung ist also wichtig für Wohlbefinden und Gesundheit. Techniken wie Atementspannung, autogenes Training oder progressive Muskelrelaxation helfen dabei. Entspannung gehört aber auch in den Alltag: Ein bewusstes Innehalten und Durchatmen in einer stressigen Situation, Muskellockerung und Bewegung statt Sitzen und Konzentrieren.");
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// app icon in action bar clicked; go home
			Intent intent = new Intent(this, MainActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent);
			return true;

		case R.id.openDayView:
			Intent oDV = new Intent(this, TagesViewActivity.class);
			startActivity(oDV);

		default:
			return super.onOptionsItemSelected(item);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_entspannung, menu);
		return true;
	}

}
