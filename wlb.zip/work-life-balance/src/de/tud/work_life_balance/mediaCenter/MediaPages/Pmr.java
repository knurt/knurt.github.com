package de.tud.work_life_balance.mediaCenter.MediaPages;

import java.io.IOException;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import de.tud.work_life_balance.MainActivity;
import de.tud.work_life_balance.R;
import de.tud.work_life_balance.TagesViewActivity;

public class Pmr extends Activity {
	MediaPlayer mp;
	String mFileName = Environment.getExternalStorageDirectory().getAbsolutePath();

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pmr);
		final ActionBar actionBar = getActionBar();
		actionBar.setDisplayHomeAsUpEnabled(true);

		ImageView bg = (ImageView) findViewById(R.id.pmrBG);
		ImageSwitcher is = (ImageSwitcher) findViewById(R.id.imageSwitcher1);
		
		Bitmap bitone = BitmapFactory.decodeFile(mFileName+"/WLB/Media/ione.jpg");
		Bitmap bittwo = BitmapFactory.decodeFile(mFileName+"/WLB/Media/itwo.jpg");
		bg.setImageBitmap(bitone);
		Uri b1 = Uri.parse(mFileName+"/WLB/Media/itwo.jpg");
		Uri b2 = Uri.parse(mFileName+"/WLB/Media/ione.jpg");
		
		try {
			player();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		Kann nicht in der onCreate verwendet werden
//		while(true){
//			is.setImageURI(b1);
//			try {
//				wait(3000);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//			is.setImageURI(b2);
//		}
		
	}
	@SuppressWarnings("static-access")
	private  void player() throws IllegalStateException, IOException {
		mp = new MediaPlayer();
		mp.setDataSource(mFileName+"/WLB/Media/PMRMusik.mp3");
		mp.prepare();
		mp.start();		
	}
	
	@Override
	protected void onDestroy(){
		super.onDestroy();
		mp.pause();
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// app icon in action bar clicked; go home
			Intent intent = new Intent(this, MainActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent);
			return true;

		case R.id.openDayView:
			Intent oDV = new Intent(this, TagesViewActivity.class);
			startActivity(oDV);

		default:
			return super.onOptionsItemSelected(item);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_pmr, menu);
		return true;
	}

}
