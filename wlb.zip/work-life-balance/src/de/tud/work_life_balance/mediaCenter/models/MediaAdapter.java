package de.tud.work_life_balance.mediaCenter.models;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import de.tud.work_life_balance.R;

public class MediaAdapter extends ArrayAdapter<MediaListItem>{
		
		private ArrayList<MediaListItem> items;

		private int layout;

		public MediaAdapter(Context context,
				int textViewResourceId, ArrayList<MediaListItem> items) {
			super(context, textViewResourceId, items);
			this.items = items;
			this.layout=textViewResourceId;
		}
		
		 @Override

		    public View getView(int position, View convertView, ViewGroup parent) {
		        View v = convertView;
		        LayoutInflater vi = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	            v = vi.inflate(R.layout.media_list_element, null);		      

		  MediaListItem item = items.get(position);



		            TextView MediaName = (TextView) v.findViewById(R.id.MediaTitel);
		            TextView MediaDescription = (TextView) v.findViewById(R.id.MediaBeschreibung);
		            ImageView image = (ImageView) v.findViewById(R.id.avatar);



		      if (item != null) {

		                MediaName.setText(item.MediaName);
		                MediaDescription.setText(item.MediaDescription);
		                
		                if(item.thumbnail!= null){
		                	
		                image.setImageDrawable(item.thumbnail);
		                	
		                }

		      }
		      



		    



		  return v;

		      

	
		    }
		 
		
		

	}


