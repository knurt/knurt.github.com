package de.tud.work_life_balance.mediaCenter.models;

import android.graphics.drawable.Drawable;

public class MediaListItem {

    public String MediaName;
    public String MediaDescription;
    public Drawable thumbnail;
	

	public MediaListItem(String MediaName, String MediaDescription , Drawable thumbnail) {
		super();
    	this.thumbnail = thumbnail;
        this.MediaDescription = MediaDescription;
        this.MediaName = MediaName;
	}


	public String getMediaName() {
		return MediaName;
	}


	public void setMediaName(String mediaName) {
		MediaName = mediaName;
	}


	public String getMediaDescription() {
		return MediaDescription;
	}


	public void setMediaDescription(String mediaDescription) {
		MediaDescription = mediaDescription;
	}


	public Drawable getThumbnail() {
		return thumbnail;
	}


	public void setThumbnail(Drawable thumbnail) {
		this.thumbnail = thumbnail;
	}
	


	
	
}
