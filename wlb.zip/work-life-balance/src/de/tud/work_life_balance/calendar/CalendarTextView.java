package de.tud.work_life_balance.calendar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * Grafisches Bedienelement, das dafuer geeignet ist, einen Tag in der
 * Monats-Ansicht anzuzeigen.
 * <p>
 * Der {@link CalendarAdapter} fuellt eine GridView mit Objekten des Klasse
 * {@link CalendarTextView}.
 * 
 * @see CalendarAdapter
 * @author Felix Mueller
 * 
 */
public class CalendarTextView extends TextView {
	private int numberOfAppointments;
	private Paint paint;
	private Rect[] rects;

	public CalendarTextView(Context c, AttributeSet a, int i) {
		super(c, a, i);
		init();
	}

	public CalendarTextView(Context c, AttributeSet a) {
		super(c, a);
		init();
	}

	public CalendarTextView(Context c) {
		super(c);
		init();
	}

	private void init() {
		paint = new Paint();
		paint.setColor(Color.DKGRAY);

		// TODO testen, wie viele rects reinpassen
		rects = new Rect[5];
		for (int i = 0; i < rects.length; ++i) {
			int x = 2 + i * 12;
			rects[i] = new Rect(x, 2, x + 8, 11);
		}
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		for (int i = 0; i < numberOfAppointments && i < rects.length; ++i) {
			canvas.drawRect(rects[i], paint);
		}
	}

	public int getNumberOfAppointments() {
		return numberOfAppointments;
	}

	public void setNumberOfAppointments(int numberOfAppointments) {
		this.numberOfAppointments = numberOfAppointments;
	}

}
