package de.tud.work_life_balance.calendar;



/**
 * 
 * @author Matthias Conrad
 * 
 * Diese Klasse stellt ein Listenelement dar welches f�r den Dialog zur Termin�berschneidung verwendet wird
 *
 */

public class AppointmentConflictListItem {
	
	String name;
	String time;
	
	/**
	 * 
	 * @param name Der Name des Termins
	 * 
	 * @param time Der Zeitpunkt des Termins
	 */
	public AppointmentConflictListItem(String name, String time) {
		super();
		this.name = name;
		this.time = time;
	}
}
