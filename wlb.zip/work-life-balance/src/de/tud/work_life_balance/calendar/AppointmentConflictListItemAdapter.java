package de.tud.work_life_balance.calendar;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import de.tud.work_life_balance.R;

/**
 * 
 * @author Matthias Conrad
 * 
 *         Diese Klasse stellt einen ListenAdapter dar, welcher
 *         Termin�berschneidungen verarbeitet
 * 
 */

public class AppointmentConflictListItemAdapter extends ArrayAdapter<AppointmentConflictListItem> {
	// Liste mit �berschneidungselementen
	private ArrayList<AppointmentConflictListItem> items;

	/**
	 * Konstruktor
	 * 
	 * @param context
	 * @param textViewResourceId
	 * @param items
	 */
	public AppointmentConflictListItemAdapter(Context context, int textViewResourceId, ArrayList<AppointmentConflictListItem> items) {

		super(context, textViewResourceId, items);
		this.items = items;
	}

	/**
	 * setzt die Elemente in die Liste
	 */
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View v = convertView;

		if (v == null) {
			LayoutInflater vi = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			v = vi.inflate(R.layout.kollisionstermin, null);
		}
		AppointmentConflictListItem item = items.get(position);
		if (item != null) {
			TextView name = (TextView) v.findViewById(R.id.kollisionName);
			TextView zeitpunkt = (TextView) v.findViewById(R.id.kollisionZeitpunkt);
			if (item != null) {
				name.setText(item.name);
				zeitpunkt.setText(item.time);
			}
		}
		return v;
	}
}
