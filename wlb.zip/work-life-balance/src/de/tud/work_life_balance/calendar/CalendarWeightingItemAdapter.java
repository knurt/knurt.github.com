package de.tud.work_life_balance.calendar;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import de.tud.work_life_balance.R;

/**
 * Diese Klasse stellt einen Adapter f&uuml;r die
 * Gewichtungsanzeige dar.
 * 
 * @author Matthias Conrad
 * 
 */
public class CalendarWeightingItemAdapter extends ArrayAdapter<CalendarWeightingListitem> {

	// Liste der Gewichtungselemente
	private ArrayList<CalendarWeightingListitem> items;

	// layout in welchem die Elemente angezeigt werden
	private int layout;

	/**
	 * Konstruktor
	 * 
	 * @param context
	 * @param textViewResourceId
	 * @param items
	 */
	public CalendarWeightingItemAdapter(Context context, int textViewResourceId, ArrayList<CalendarWeightingListitem> items) {
		super(context, textViewResourceId, items);
		this.items = items;
		this.layout = textViewResourceId;
	}

	// Liste wird mit gewichtungselementen gef�llt
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		View v = convertView;

		LayoutInflater vi = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		v = vi.inflate(R.layout.kalender_gewichtungs_listitem, null);

		final CalendarWeightingListitem item = items.get(position);

		TextView menue = (TextView) v.findViewById(R.id.bereich);
		menue.setText(item.weighting);

		SeekBar bar = (SeekBar) v.findViewById(R.id.gewichtungsBar);
		bar.setProgress(item.value);

		// speicherung der Gewichtungswerte wenn seekbar ver�ndert wird
		bar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
			}

			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				item.value = progress;
			}
		});

		// wenn Termin angezeigt wird -> keine ver�nderung der seekbar mehr
		// m�glich
		if (layout == R.layout.kalender_gewichtungs_listitem2) {

			bar.setEnabled(false);
		}

		return v;
	}
}
