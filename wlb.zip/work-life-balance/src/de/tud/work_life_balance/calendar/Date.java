package de.tud.work_life_balance.calendar;

import java.io.Serializable;
import java.util.Calendar;
import java.util.GregorianCalendar;

import android.annotation.SuppressLint;

/**
 * 
 * Die Klasse stellt ein Datum dar!
 * 
 * @author Matthias Conrad
 *
 */

public class Date implements Comparable<Date>, Serializable {

	
	private static final long serialVersionUID = 1L;
	
	//Ein Datum hat ein tag monat und Jahr
	private int day, month, year;

	
	/**
	 * Konstruktor
	 * 
	 * @param day Der Tag des Datums 
	 * @param month Der Monat des Datums
	 * @param year Das Jahr des Datums
	 */
	public Date(int day, int month, int year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}

	/**
	 * default Konstruktor
	 */
	public Date() {
		day = 1;
		month = 0;
		year = 1970;
	}
	
	/**
	 * Konstruktor
	 * 
	 * @param calendar Ein Kalender wird �bergeben
	 */
	public Date(Calendar calendar) {
		// Ich gehe davon aus, dass 0 fuer Januar steht.
		this.day = calendar.get(Calendar.DAY_OF_MONTH);
		this.month = calendar.get(Calendar.MONTH);
		this.year = calendar.get(Calendar.YEAR);
	}
	
	public Calendar getCalendarFormat() {
		return new GregorianCalendar(year, month, day);
	}
	
	public long getTimeInMillis() {
		return new GregorianCalendar(year, month, day).getTimeInMillis();
	}

	/**
	 * Gibt Datum als String zur�ck
	 */
	
	@SuppressLint("DefaultLocale")
	public String toString() {
		return String.format("%d.%d.%d", day, month + 1, year);
	}

	/**
	 * @return the day
	 */
	public int getDay() {
		return day;
	}

	/**
	 * @return the month
	 */
	public int getMonth() {
		return month;
	}

	/**
	 * @return the year
	 */
	public int getYear() {
		return year;
	}

	/**
	 * @param day
	 *            the day to set
	 */
	public void setDay(int day) {
		this.day = day;
	}

	/**
	 * @param month
	 *            the month to set
	 */
	public void setMonth(int month) {
		this.month = month;
	}

	/**
	 * @param year
	 *            the year to set
	 */
	public void setYear(int year) {
		this.year = year;
	}

	
	/**
	 * vergleicht zwei daten
	 */
	@Override
	public int compareTo(Date other) {
		if (this.year > other.year)
			return 1;
		if (this.year < other.year)
			return -1;
		if (this.month > other.month)
			return 1;
		if (this.month < other.month)
			return -1;
		if (this.day > other.day)
			return 1;
		if (this.day < other.day)
			return -1;
		return 0;
	}

}
