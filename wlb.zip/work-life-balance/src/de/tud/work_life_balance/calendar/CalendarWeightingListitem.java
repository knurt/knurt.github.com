package de.tud.work_life_balance.calendar;

/**
 * 
 * Diese Klasse stellt ein GewichtungsListenelement dar
 * 
 * @author Matthias Conrad
 *
 */
public class CalendarWeightingListitem {
	
	String weighting;
	int value;

	/**
	 * Konstruktor
	 * 
	 * @param weighting  Die Gewichtungsart
	 * @param value Der wert der Gewichtung
	 */
	
	public CalendarWeightingListitem(String weighting, int value) {
		super();
		this.weighting = weighting;
		this.value=value;
	}

	/**
	 * @return the gewichtung
	 */
	public String getWeighting() {
		return weighting;
	}

	/**
	 * @return the wert
	 */
	public int getValue() {
		return value;
	}

	/**
	 * @param weighting the weighting to set
	 */
	public void setWeighting(String weighting) {
		this.weighting = weighting;
	}

	/**
	 * @param value the wert to set
	 */
	public void setValue(int value) {
		this.value = value;
	}

}
