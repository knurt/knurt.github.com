package de.tud.work_life_balance.calendar;

import java.io.Serializable;
import java.util.GregorianCalendar;

/**
 * 
 * @author Matthias Conrad
 * 
 *         Diese Klasse ist stellt einen Termin dar, der in den Kalender
 *         eingetragen werden kann.
 * 
 */
public class Appointment implements Comparable<Appointment>, Serializable {

	private static final long serialVersionUID = 1771649657603272664L;

	// Zähler welche sich beim erstellen eines Termins um eins hochzählen
	private static long idCounter = 1;

	// Wiederholungstermine haben eine gemeinsame "serialIdCounter"
	private static long serialIdCounter = 1;

	// ID zur eindeutigen identifikation
	private long id;

	// ID fuer serientermine
	private long serienID;

	// Datum
	private Date startdate;
	private Date enddate;
	// Zeiten:
	private Time starttime;
	private Time endtime;
	// Gewichtung
	private Weighting weighting;
	// Name
	private String name;
	// ist termin ganztaegig
	private Boolean allday;
	// Terminbeschreibung
	private String description;
	/**
	 * Wiederholung des termins
	 * 
	 * <li>0 = Einmaliges Ereignis <li>1 = Täglich <li>2 = Wöchentlich <li>3 =
	 * Monatlich
	 */
	private int repeat;

	/**
	 * Termin Erinnerung (Arlarm) <li>0 steht für keine Erinnerung <li>1 steht
	 * für 10 Min vorher <li>2 steht für 30 Min vorher <li>3 steht für 1 Stunde
	 * vorher <li>4 steht für 2 Stunden vorher
	 */
	private int reminder;
	// Ortsangabe
	private String place;

	public static final int MILLIS_PER_MINUTE = 60000;

	public static final int REM_NOT = 0;
	public static final int REM_10M = 1;
	public static final int REM_30M = 2;
	public static final int REM_1H = 3;
	public static final int REM_2H = 4;

	public static final int REPEAT_NOT = 0;
	public static final int REPEAT_DAYLY = 1;
	public static final int REPEAT_WEEKLY = 2;
	public static final int REPEAT_MONTHLY = 3;

	/**
	 * Konstruktor f&uuml;r einen Termin
	 * 
	 * @param startdate
	 *            Das Startdatum
	 * @param enddate
	 *            Das Enddatum
	 * @param starttime
	 *            Die Startzeit
	 * @param endtime
	 *            Die Endzeit
	 * @param weighting
	 *            Die Gewichtungen
	 * @param name
	 *            Der Name des Termins
	 * @param description
	 *            Die Beschreibzng des Termins
	 * @param repeat
	 *            Der Wiederholungintervall eines Termins
	 * @param reminder
	 *            Die Erinnerungsfunktion
	 * @param place
	 *            Der Ort des Termins
	 */
	public Appointment(Date startdate, Date enddate, Time starttime,
			Time endtime, Weighting weighting, String name, String description,
			int repeat, int reminder, String place) {
		super();
		this.startdate = startdate;
		this.enddate = enddate;
		this.starttime = starttime;
		this.endtime = endtime;
		this.weighting = weighting;
		this.name = name;
		this.allday = false;
		this.description = description;
		this.repeat = repeat;
		this.reminder = reminder;
		this.place = place;
		// Termin ID wird fortlaufend gesetzt
		this.id = idCounter++;
		serienID = 0;
	}

	/**
	 * Konstruktor ohne Zuweisungen
	 */
	public Appointment() {
		this.allday = false;
		this.startdate = new Date();
		this.enddate = new Date();
		this.starttime = new Time();
		this.endtime = new Time();
		this.weighting= new Weighting();
		this.name = "";
		this.description = "";
		this.reminder = 0;
		this.repeat = 0;
		this.place = "";
		this.id = idCounter++;
		serienID = 0;
	}

	/**
	 * Legt ein neues Appointment-Objekt an, das identisch zum übergebenen
	 * Appointment-Objekt ist.
	 * 
	 * @param appointment
	 *            Vorlage-Termin
	 */
	public Appointment(Appointment appointment) {
		this.allday = appointment.allday;
		this.description = appointment.description;
		this.reminder = appointment.reminder;
		this.startdate = appointment.startdate;
		this.enddate = appointment.enddate;
		this.weighting=appointment.weighting;
		this.starttime = appointment.starttime;
		this.endtime = appointment.endtime;
		this.repeat = appointment.repeat;
		this.name = appointment.name;
		this.place = appointment.place;
		this.serienID=appointment.serienID;
		this.id = idCounter++;
	}

	/**
	 * Gibt den Termin(Datum,Uhrzeit,Name) als String aus
	 */
	public String toString() {
		return String.format("%s %s -> %s %s : %s", startdate, starttime,
				enddate, endtime, name);
	}

	/**
	 * @return das Startdatum
	 */
	public Date getStartdate() {
		return startdate;
	}

	/**
	 * @return das Enddatum
	 */
	public Date getEnddate() {
		return enddate;
	}

	/**
	 * @return die Startzeit
	 */
	public Time getStarttime() {
		return starttime;
	}

	/**
	 * @return die Endzeit
	 */
	public Time getEndtime() {
		return endtime;
	}

	/**
	 * @see Weighting
	 * @return die Gewichtung
	 */
	public Weighting getWeighting() {
		return weighting;
	}

	/**
	 * @return Name des Termins
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param startdate
	 *            zu setzendes Startdatum
	 */
	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	/**
	 * @param enddate
	 *            zu setzendes Enddatum
	 */
	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

	/**
	 * @param starttime
	 *            zu setzende Startzeit
	 */
	public void setStarttime(Time starttime) {
		this.starttime = starttime;
	}

	/**
	 * @param endtime
	 *            zu setzende Endzeit
	 */
	public void setEndtime(Time endtime) {
		this.endtime = endtime;
	}

	/**
	 * @see Weighting
	 * @param weighting
	 *            zu setzende Gewichtung
	 */
	public void setWeighting(Weighting weighting) {
		this.weighting = weighting;
	}

	/**
	 * Legt eine ausführlichere Beschreibung des Termins fest.
	 * 
	 * @param description
	 *            zu setzendes Beschreibung
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return ob der Termin den ganzen Tag überspannt
	 */
	public Boolean isAllday() {
		return allday;
	}

	/**
	 * @param allday
	 *            ob der Termin den ganzen Tag überspannen soll
	 */
	public void setAllday(Boolean allday) {
		this.allday = allday;
	}

	/**
	 * @return die beschreibung
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            die zu setzende Beschreibung
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * <li>0 = Einmaliges Ereignis <li>1 = Täglich <li>2 = Wöchentlich <li>3 =
	 * Monatlich
	 * 
	 * @return die Wiederholung
	 */
	public int getRepeat() {
		return repeat;
	}

	/**
	 * <li>0 steht für keine Erinnerung <li>1 steht für 10 Min vorher <li>2
	 * steht für 30 Min vorher <li>3 steht für 1 Stunde vorher <li>4 steht für 2
	 * Stunden vorher
	 * 
	 * @return Die erinnerung
	 */
	public int getReminder() {
		return reminder;
	}

	/**
	 * @return the ort
	 */
	public String getplace() {
		return place;
	}

	/**
	 * Konstanten sind in der Appointment-Klasse definiert.
	 * 
	 * @param repeat
	 *            the wiederholung to set
	 */
	public void setRepeat(int repeat) {
		this.repeat = repeat;
	}

	/**
	 * Konstanten sind in der Appointment-Klasse definiert.
	 * 
	 * @param reminder
	 *            Zeit
	 */
	public void setReminder(int reminder) {
		this.reminder = reminder;
	}

	/**
	 * @param place
	 *            Der Ord des Termins
	 */
	public void setPlace(String place) {
		this.place = place;
	}

	/**
	 * @return Die Identifikationsnummer des Termins
	 */
	public long getId() {
		return id;
	}

	/**
	 * @return serienID Die serienID, die alle Instanzen eines
	 *         Wiederholungstermins teilen.
	 */
	public long getSerienID() {
		return serienID;
	}

	/**
	 * @param serienID
	 *            Die serienID, die alle Instanzen eines Wiederholungstermins
	 *            teilen.
	 */
	public void setSerienID() {
		this.serienID = serialIdCounter;
		serialIdCounter++;
	}

	/**
	 * vergleicht zwei Termine hinsichtlich ihres Startzeitpunktes
	 * 
	 * @param der
	 *            Vergreichstermin
	 */
	@Override
	public int compareTo(Appointment other) {
		int dayComparison = this.getStartdate().compareTo(other.getStartdate());
		if (dayComparison != 0) {
			return dayComparison;
		} else {
			int timeComparison = this.getStarttime().compareTo(
					other.getStarttime());
			if (timeComparison != 0) {
				return timeComparison;
			} else {
				// Es darf nur 0 ausgegeben werden, wenn die Objekte gleich sind
				if (this.equals(other)) {
					return 0;
				} else {
					return 1;
				}
			}
		}
	}

	/**
	 * 
	 * @return den Startzeitpunkt des Termins in Millisekunden
	 */
	public long getStartInMillis() {
		return new GregorianCalendar(startdate.getYear(), startdate.getMonth(),
				startdate.getDay(), starttime.getHour(), starttime.getMinute())
				.getTimeInMillis();
	}

	/**
	 * 
	 * @return den Endzeitpunkt des Termins in Millisekunden
	 */
	public long getEndInMillis() {
		return new GregorianCalendar(enddate.getYear(), enddate.getMonth(),
				enddate.getDay(), endtime.getHour(), endtime.getMinute())
				.getTimeInMillis();
	}

	/**
	 * 
	 * @return den Startzeitpunkt des Termins in Minuten
	 */
	public long getStartInMinutes() {
		return new GregorianCalendar(startdate.getYear(), startdate.getMonth(),
				startdate.getDay(), starttime.getHour(), starttime.getMinute())
				.getTimeInMillis()
				/ MILLIS_PER_MINUTE;
	}

	/**
	 * 
	 * @return Die Endzeitpunkt des Termins in Minuten
	 */
	public long getEndInMinutes() {
		return new GregorianCalendar(enddate.getYear(), enddate.getMonth(),
				enddate.getDay(), endtime.getHour(), endtime.getMinute())
				.getTimeInMillis()
				/ MILLIS_PER_MINUTE;
	}

	/**
	 * @return die Zeitlänge des Termins in Minuten
	 */
	public int getLengthInMinutes() {
		return (int) (getEndInMinutes() - getStartInMinutes());
	}

}
