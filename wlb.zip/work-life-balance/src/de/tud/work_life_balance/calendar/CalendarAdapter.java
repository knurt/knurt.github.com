package de.tud.work_life_balance.calendar;

import java.util.Calendar;
import java.util.SortedSet;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.util.MonthDisplayHelper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import de.tud.work_life_balance.R;

/**
 * Diese Klasse ist fuer das Anzeigen eines Monats zustaendig.
 * <p>
 * Sie muss mit einer {@link GridView} mittels {@link GridView.setAdapter}
 * verbunden werden.
 * 
 * @author Felix Mueller
 * 
 */
public class CalendarAdapter extends BaseAdapter {
	private static final int COLUMN_COUNT = 8;
	private Context context;
	private Calendar selectedDate;
	private Calendar visibleMonth; // Tag und Uhrzeit werden ignoriert
	private de.tud.work_life_balance.calendar.Calendar calendar;
	private MonthDisplayHelper visibleMonthHelper;
	private static int androidBlue;
	private static final String[] weekDayNames = new String[] { "", "Mo", "Di",
			"Mi", "Do", "Fr", "Sa", "So" };

	public CalendarAdapter(Context context, Calendar currentDate,
			de.tud.work_life_balance.calendar.Calendar calendar) {
		androidBlue = context.getResources().getColor(
				R.color.android_light_blue);
		selectedDate = (Calendar) currentDate.clone();
		visibleMonth = (Calendar) selectedDate.clone();
		this.calendar = calendar;
		this.context = context;
		visibleMonthHelper = new MonthDisplayHelper(
				visibleMonth.get(Calendar.YEAR),
				visibleMonth.get(Calendar.MONTH), Calendar.MONDAY);
		notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		return 55; // 8 * 7 - 1
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return position / 8;
	}

	// create a new view for each item referenced by the Adapter
	@Override
	public View getView(int position, View oldView, ViewGroup parent) {
		if (oldView == null) {
			// if it's not recycled, initialize some attributes
			LayoutInflater vi = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			oldView = vi.inflate(R.layout.calendar_item, null);
		}

		CalendarTextView tvDate = (CalendarTextView) oldView
				.findViewById(R.id.tvDate);

		tvDate.setVisibility(View.INVISIBLE);

		if (position < COLUMN_COUNT) {
			tvDate.setText(weekDayNames[position]);
			tvDate.setVisibility(View.VISIBLE);
		} else if (position % COLUMN_COUNT == 0) {
			// Kalenderwoche
			// Beim setzen von WEEK_OF_MONTH, kann der Monat geaendert werden -
			// deshalb wird der Tag gesichert
			int oldDay = visibleMonth.get(Calendar.DAY_OF_YEAR);
			visibleMonth.set(Calendar.WEEK_OF_MONTH, position / 8);
			tvDate.setText(Integer.toString(visibleMonth
					.get(Calendar.WEEK_OF_YEAR)));
			visibleMonth.set(Calendar.DAY_OF_YEAR, oldDay); // Tag aus sicherung
															// wiederherstellen
			tvDate.setTextColor(Color.GRAY);
			tvDate.setVisibility(View.VISIBLE);
		} else if (posIsDay(position)) {
			Log.d("CalendarAdapter", " pos " + position + " wird sichtbar");
			int dayOfMonth = posToCalendarDayOfMonth(position);
			Log.d("CalendarAdapter", " Tages-NUmmer " + dayOfMonth);

			Calendar currentDay = (Calendar) visibleMonth.clone();
			currentDay.set(Calendar.DAY_OF_MONTH, dayOfMonth);
			currentDay.set(Calendar.HOUR_OF_DAY, 0);
			long startMillis = currentDay.getTimeInMillis();
			currentDay.add(Calendar.DAY_OF_YEAR, 1);
			long endMillis = currentDay.getTimeInMillis();

			SortedSet<Appointment> apps = calendar.getAppointmentsBetween(
					startMillis, endMillis);
			tvDate.setNumberOfAppointments(apps.size());
			tvDate.setText(Integer.toString(dayOfMonth));
			tvDate.setTextSize(26);

			int backgroundColor = Color.LTGRAY;
			if (dayOfMonth == selectedDate.get(Calendar.DAY_OF_MONTH)
					&& visibleMonth.get(Calendar.MONTH) == selectedDate
							.get(Calendar.MONTH)) {
				backgroundColor = androidBlue;
			}
			tvDate.setBackgroundColor(backgroundColor);

			tvDate.setVisibility(View.VISIBLE);
		}

		return oldView;
	}

	private int posToCalendarDayOfMonth(int pos) {
		pos = pos - 8; // Zeile fuer Wochentagsnamen
		int row = pos / 8;
		int column = pos % 8 - 1;
		return visibleMonthHelper.getDayAt(row, column);
	}

	public boolean posIsDay(int position) {
		return position >= getPosOfFirstDay() && (position % 8) != 0
				&& position <= getPosOfLastDay();
	}

	private int getPosOfLastDay() {
		// FIXME manchmal werden zu viele Tage angezeigt, wenn man den Monat
		// wechselt
		int daysInMonth = visibleMonth.getActualMaximum(Calendar.DAY_OF_MONTH);
		Log.d("CalendarAdapter",
				"asdasd " + visibleMonthHelper.getRowOf(daysInMonth));
		// getRowOf(daysInMonth) == Anzahl der Wochen-Zahlen - 1
		return getPosOfFirstDay() + visibleMonthHelper.getRowOf(daysInMonth)
				+ daysInMonth - 1;
	}

	private int getPosOfFirstDay() {
		int result = visibleMonthHelper.getColumnOf(1) + COLUMN_COUNT + 1;
		return result;
	}

	public Calendar getSelectedDate() {
		return (Calendar) selectedDate.clone();
	}

	public void setSelectedDay(int position) {
		int dayOfMonth = posToCalendarDayOfMonth(position);
		selectedDate.set(Calendar.MONTH, visibleMonth.get(Calendar.MONTH));
		selectedDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);
	}

	public int addToMonth(int delta) {
		// FIXME Wenn man in Dezember letzten Jahres wechselt, aendert sich das
		// Jahr nicht
		visibleMonth.add(Calendar.MONTH, delta);
		if (delta == 1) {
			visibleMonthHelper.nextMonth();
		} else if (delta == -1) {
			visibleMonthHelper.previousMonth();
		} else {
			throw new IllegalArgumentException();
		}

		return visibleMonth.get(Calendar.MONTH);
	}
}