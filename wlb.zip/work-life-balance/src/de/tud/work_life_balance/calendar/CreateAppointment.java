package de.tud.work_life_balance.calendar;

import java.util.ArrayList;
import java.util.LinkedList;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import de.tud.work_life_balance.MainActivity;
import de.tud.work_life_balance.R;
import de.tud.work_life_balance.settings.AlarmReceiver;

/**
 * Activity in dieser man einen neuen Termin anlegen/bearbeiten kann
 * 
 * @author Matze
 * 
 */
public class CreateAppointment extends Activity {

	// der aktuelle Termin
	private static Appointment appointment;

	// termin der gespeichert wird wenn bei der bearbeitung abgebrochen wird
	private Appointment appointmentBackup;

	// Edittext Datum/Uhrzeit
	private View input;

	// Liste von kollisionsterminen
	private LinkedList<Appointment> conflictAppointments;

	// Dialoge zur auswahl von datum/Uhrzeit usw.
	private Dialog dlg_date;
	private Dialog dlg_time;
	private Dialog dauer;
	private Dialog dlg_repeat;
	private Dialog dlg_reminder;
	private Dialog dlg_conflict;
	private Dialog dlg_abort;

	// Gewichtungsliste und Adapter
	private ArrayList<CalendarWeightingListitem> menuePoints;
	private CalendarWeightingItemAdapter adapter;

	// gewichtung schon gesetzt?
	// private boolean koerper = false;
	// private boolean beruf = false;
	// private boolean sinn = false;
	// private boolean kontakt = false;

	// gewichtungselemente
	private CalendarWeightingListitem carrer;
	private CalendarWeightingListitem body;
	private CalendarWeightingListitem mind;
	private CalendarWeightingListitem social;

	// alarmmanager fuer Erinnerung
	AlarmManager am;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_calender_neuer_termin);

		// wenn kein termin uebergeben wurde
		if (appointment == null) {

			// termin anlegen
			appointment = new Appointment();
			// TODO Idee: Man koennte den "new Termin()"-Konstruktor
			// so bauen, dass er das Gleiche tut.

			// gewichtungselemente
			carrer = new CalendarWeightingListitem(getString(R.string.beruf), 0);
			body = new CalendarWeightingListitem(getString(R.string.koerper), 0);
			mind = new CalendarWeightingListitem(getString(R.string.sinn), 0);
			social = new CalendarWeightingListitem(getString(R.string.kontakt),
					0);
		} else {
			appointmentBackup = appointment;
			editAppointment();
		}

		buildActivity();

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_calender_neuer_termin, menu);
		return true;
	}

	/**
	 * Baut die Activity auf
	 * 
	 */
	private void buildActivity() {

		menuePoints = new ArrayList<CalendarWeightingListitem>();

		// gewichtung hinzufuegen
		menuePoints.add(carrer);
		// beruf = true;

		// listview adapter zuweisen
		ListView menueList = (ListView) findViewById(R.id.gewichtungsListe);

		adapter = new CalendarWeightingItemAdapter(this,
				R.layout.kalender_gewichtungs_listitem, menuePoints);
		menueList.setAdapter(adapter);

		// Autocomplete für orte
		AutoCompleteTextView ort = (AutoCompleteTextView) findViewById(R.id.ort_editText);

		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, MainActivity.getProfil()
						.getOrte());
		ort.setAdapter(adapter);

		addListener();
	}

	/**
	 * laed die angeklickte Gewichtung in die Activity
	 * 
	 * @param view
	 *            ist der Gewichtungsbutton der gedrueckt wurde
	 */
	public void selectWeighting(View view) {

		if (view.getId() == R.id.gewichtungsbutton_koerper) {
			// if (koerper) {
			// menuePoints.remove(koerper_g);
			// koerper = false;
			// } else {
			// menuePoints.add(koerper_g);
			// koerper = true;
			// }
			menuePoints.clear();
			menuePoints.add(body);

		}

		if (view.getId() == R.id.gewichtungsbutton_sinn) {
			// if (sinn) {
			// menuePoints.remove(sinn_g);
			// sinn = false;
			// } else {
			// menuePoints.add(sinn_g);
			// sinn = true;
			// }
			menuePoints.clear();
			menuePoints.add(mind);
		}

		if (view.getId() == R.id.gewichtungsbutton_kontakt) {
			// if (kontakt) {
			// menuePoints.remove(kontakt_g);
			// kontakt = false;
			// } else {
			// menuePoints.add(kontakt_g);
			// kontakt = true;
			// }
			menuePoints.clear();
			menuePoints.add(social);
		}

		if (view.getId() == R.id.gewichtungsbutton_beruf) {
			// if (beruf) {
			// menuePoints.remove(beruf_g);
			// beruf = false;
			// } else {
			// menuePoints.add(beruf_g);
			// beruf = true;
			// }
			menuePoints.clear();
			menuePoints.add(carrer);
		}

		// adapter aktualisieren
		adapter.notifyDataSetChanged();
	}

	/**
	 * Baut ein Dialog auf, in welchem man die Startzeit bzw. Endzeit des
	 * Termins auswählen kann!
	 * 
	 * @param view
	 *            ist ein Edittext (Startzeit oder Endzeit)
	 */
	public void selectTime(View view) {

		this.input = view;

		// datums dialog anzeigen!
		dlg_time = new Dialog(this);
		dlg_time.setContentView(R.layout.zeit_auswahl);

		// dauer hinzufuegen
		if (view.getId() == R.id.zeit_editText1) {
			TextView dauer = (TextView) dlg_time
					.findViewById(R.id.termin_dauer_textView);
			dauer.setVisibility(1);
			EditText dauer1 = (EditText) dlg_time
					.findViewById(R.id.dauer_editText);
			dauer1.setVisibility(1);

			// dialogtitel festlegen
			dlg_time.setTitle(getString(R.string.startzeit));

		} else {
			dlg_time.setTitle(getString(R.string.endzeit));
		}

		TimePicker zeit = (TimePicker) dlg_time.findViewById(R.id.timePicker1);
		zeit.setIs24HourView(true);

		dlg_time.show();

		// buttons anklickbar
		Button ok = (Button) dlg_time.findViewById(R.id.zeit_ok);
		Button abbruch = (Button) dlg_time.findViewById(R.id.zeit_abbrechen);

		ok.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				TimePicker zeit = (TimePicker) dlg_time
						.findViewById(R.id.timePicker1);

				int std = zeit.getCurrentHour();
				int min = zeit.getCurrentMinute();

				// Zeit festlegen
				if (input.getId() == R.id.zeit_editText1) {

					EditText von = (EditText) findViewById(R.id.zeit_editText1);

					// speicherung im termin
					appointment.getStarttime().setMinute(min);
					appointment.getStarttime().setHour(std);

					// zeit zuweisen
					von.setText(appointment.getStarttime().toString());

					// EndZeit mit Termindauer festlegen
					EditText text = (EditText) dlg_time
							.findViewById(R.id.dauer_editText);

					if (dauer != null && text.getText().length() > 0) {
						TimePicker time = (TimePicker) dauer
								.findViewById(R.id.timePicker1);
						int dm = min + time.getCurrentMinute();
						int ds = time.getCurrentHour() + std + (dm / 60);
						dm = dm % 60;
						ds = ds % 24;
						// dauer dazuzaehlen
						appointment.getEndtime().setMinute(dm);
						appointment.getEndtime().setHour(ds);

						// datum bei ueberlauf korrigieren

						// wenn datum ausgewaehlt und startsatum=enddatum
						if (dlg_date != null
								&& appointment
										.getStartdate()
										.toString()
										.equals(appointment.getEnddate()
												.toString())) {
							// wenn startzeit > Endzeit
							if (appointment.getEndtime().compareTo(
									appointment.getStarttime()) < 0)

							{

								// dann Enddatum=startdatum+1
								DatePicker date = (DatePicker) dlg_date
										.findViewById(R.id.DatePicker1);
								EditText datum = (EditText) findViewById(R.id.datum_editText2);

								date.updateDate(date.getYear(),
										date.getMonth(),
										date.getDayOfMonth() + 1);
								appointment.getEnddate().setDay(
										date.getDayOfMonth());
								appointment.getEnddate().setMonth(
										date.getMonth()); // +1?
								appointment.getEnddate()
										.setYear(date.getYear());
								datum.setText(appointment.getEnddate()
										.toString());

								// datepicker wieder zuruecksetzen
								date.updateDate(appointment.getStartdate()
										.getYear(), appointment.getStartdate()
										.getMonth(), appointment.getStartdate()
										.getDay());

							}
						}

					}
					// Endzeit ohne Termindauer festlegen (Startzeit+ 1 std)
					else {
						appointment.getEndtime().setMinute(
								appointment.getStarttime().getMinute());
						appointment.getEndtime().setHour(
								appointment.getStarttime().getHour() + 1);
					}
					// endzeit setzen
					EditText bis = (EditText) findViewById(R.id.zeit_editText2);
					bis.setText(appointment.getEndtime().toString());
				}

				// Endzeit festlegen
				if (input.getId() == R.id.zeit_editText2) {
					EditText bis = (EditText) findViewById(R.id.zeit_editText2);

					// speicherung im termin
					appointment.getEndtime().setMinute(min);
					appointment.getEndtime().setHour(std);
					bis.setText(appointment.getEndtime().toString());

					// abfrage wegen datumsueberlauf
					EditText datum = (EditText) findViewById(R.id.datum_editText2);
					EditText datum1 = (EditText) findViewById(R.id.datum_editText1);
					EditText von = (EditText) findViewById(R.id.zeit_editText1);

					// wenn startzeit gesetzt und startdatum + endatum gleich
					// sind
					if (von.getText().length() > 0
							&& datum.getText().toString()
									.equals(datum1.getText().toString())) {
						// wenn ein datum ausgewählt wurde
						if (dlg_date != null) {
							// und wenn Endzeit < Startzeit
							if (appointment.getEndtime().compareTo(
									appointment.getStarttime()) < 0) {

								DatePicker date = (DatePicker) dlg_date
										.findViewById(R.id.DatePicker1);

								date.updateDate(date.getYear(),
										date.getMonth(),
										date.getDayOfMonth() + 1);
								appointment.getEnddate().setDay(
										date.getDayOfMonth());
								appointment.getEnddate().setMonth(
										date.getMonth());

								appointment.getEnddate()
										.setYear(date.getYear());
								datum.setText(appointment.getEnddate()
										.toString());

								// datepicker wieder zuruecksetzen
								date.updateDate(appointment.getStartdate()
										.getYear(), appointment.getStartdate()
										.getMonth(), appointment.getStartdate()
										.getDay());

							}
						}
					}
				}
				// dialog beenden
				dlg_time.dismiss();
			}
		});

		abbruch.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				dlg_time.dismiss();
			}
		});

		// listener fuer termindauer
		EditText dauer = (EditText) dlg_time.findViewById(R.id.dauer_editText);

		dauer.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				selectDuratrion(v);
			}
		});
	}

	/**
	 * Baut ein Dialog auf, in welchem man das Datum auswaehlen kann
	 * 
	 * @param view
	 *            ist ein Edittext (Startdatum oder Enddatum)
	 */
	public void selectDate(View view) {

		this.input = view;

		// datums dialog anzeigen!
		dlg_date = new Dialog(this);
		dlg_date.setContentView(R.layout.datum_auswahl);
		dlg_date.setTitle(getString(R.string.datum_wahl));
		dlg_date.show();

		// buttons anklickbar
		Button ok = (Button) dlg_date.findViewById(R.id.datum_ok);
		Button abbruch = (Button) dlg_date.findViewById(R.id.datum_abbrechen);

		ok.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				// Datepicker zum erfassen der zeit
				DatePicker datum = (DatePicker) dlg_date
						.findViewById(R.id.DatePicker1);
				Log.d("CalenderNeuerTermin",
						String.format("%d.%d.%d", datum.getDayOfMonth(),
								datum.getMonth(), datum.getYear()));

				// EditText-felder startdatum + enddatum
				EditText von = (EditText) findViewById(R.id.datum_editText1);
				EditText bis = (EditText) findViewById(R.id.datum_editText2);
				// EditTestfelder startzeit + endzeit
				EditText zeit = (EditText) findViewById(R.id.zeit_editText2);

				// startdatum speichern
				if (input.getId() == R.id.datum_editText1) {
					// Datum in termin speichern
					appointment.getStartdate().setYear(datum.getYear());
					appointment.getStartdate().setMonth(datum.getMonth()); // +
																			// 1
					appointment.getStartdate().setDay(datum.getDayOfMonth());

					// wenn datum nicht korrekt dann korregieren
					if (bis.getText().length() > 0) {
						checkDate();
						bis.setText(appointment.getEnddate().toString());
					}

					// Startdatum setzen
					von.setText(appointment.getStartdate().toString());

					// enddatum nur setzen wenn noch nicht gesetzt
					if (appointment.getEnddate() != null) {

						// abfrage wegen datumsueberlauf

						// wenn endzeit gesetzt
						if (appointment.getEndtime() != null) {
							// wenn endzeit < startzeit
							if (appointment.getEndtime().compareTo(
									appointment.getStarttime()) < 0) {
								// setze Enddatum =Startdatum+1
								datum.updateDate(datum.getYear(),
										datum.getMonth(),
										datum.getDayOfMonth() + 1);
							}
						}

						// Datum in termin speichern
						appointment.getEnddate().setYear(datum.getYear());
						appointment.getEnddate().setMonth(datum.getMonth());
						appointment.getEnddate().setDay(datum.getDayOfMonth());
						// datum setzen
						bis.setText(appointment.getEnddate().toString());

						// datepicker wieder zuruecksetzen
						datum.updateDate(appointment.getStartdate().getYear(),
								appointment.getStartdate().getMonth(),
								appointment.getStartdate().getDay());

					}
				}

				// Enddatum setzen
				if (input.getId() == R.id.datum_editText2) {
					appointment.getEnddate().setYear(datum.getYear());
					appointment.getEnddate().setMonth(datum.getMonth());
					appointment.getEnddate().setDay(datum.getDayOfMonth());

					// wenn startdate = Enddate u. Starttime > Endtime
					if (appointment.getEnddate().compareTo(
							appointment.getStartdate()) == 0
							&& appointment.getEndtime().compareTo(
									appointment.getStarttime()) < 0) {
						// setze Enddatum =Startdatum+1
						datum.updateDate(datum.getYear(), datum.getMonth(),
								datum.getDayOfMonth() + 1);
						// neues enddatum speicher
						appointment.getEnddate().setYear(datum.getYear());
						appointment.getEnddate().setMonth(datum.getMonth());
						appointment.getEnddate().setDay(datum.getDayOfMonth());

						// datepicker wieder zuruecksetzen
						datum.updateDate(appointment.getStartdate().getYear(),
								appointment.getStartdate().getMonth(),
								appointment.getStartdate().getDay());

					}
					// Enddatum darf nicht < startdatum sein!
					checkDate();

					// Enddatum setzen

					bis.setText(appointment.getEnddate().toString());

					// datepicker wieder zuruecksetzen
					datum.updateDate(appointment.getStartdate().getYear(),
							appointment.getStartdate().getMonth(), appointment
									.getStartdate().getDay());

				}
				// dialog beenden
				dlg_date.dismiss();
			}
		});

		abbruch.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				dlg_date.dismiss();
			}
		});
	}

	/**
	 * Baut ein Dialog auf, in welchem man die Dauer des Termins auswaehlen kann
	 * 
	 * @param view
	 *            ist ein Edittext(Dauer)
	 */
	public void selectDuratrion(View view) {
		// datums dialog anzeigen!
		dauer = new Dialog(this);
		dauer.setContentView(R.layout.zeit_auswahl);

		TimePicker zeit = (TimePicker) dauer.findViewById(R.id.timePicker1);
		zeit.setIs24HourView(true);

		dauer.setTitle(getString(R.string.dauer_wahl));

		dauer.show();

		// buttons anklickbar
		Button ok = (Button) dauer.findViewById(R.id.zeit_ok);
		Button abbruch = (Button) dauer.findViewById(R.id.zeit_abbrechen);

		ok.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				// timepicker zum erfassen der zeit
				TimePicker zeit = (TimePicker) dauer
						.findViewById(R.id.timePicker1);

				// stunden + Minuten
				String minuten;
				String stunden;
				// minuten < 10 dann setzen eine 0 davor
				if (zeit.getCurrentMinute() < 10) {
					minuten = "0" + Integer.toString(zeit.getCurrentMinute());
				} else {
					minuten = Integer.toString(zeit.getCurrentMinute());

				}

				// stunden festlegen
				stunden = Integer.toString(zeit.getCurrentHour());
				// ausgabezeit basteln
				String z = stunden + " : " + minuten;
				// edittext die zeit ï¿œbergeben
				EditText termindauer = (EditText) dlg_time
						.findViewById(R.id.dauer_editText);
				termindauer.setText(z);
				// dialog beenden
				dauer.dismiss();
			}
		});

		abbruch.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// dialog beenden
				dauer.dismiss();
			}
		});

	}

	/**
	 * aktiviert alles Buttons uns Textfelder
	 * 
	 */
	public void addListener() {
		// clicklistener fuer Zeit von
		EditText von = (EditText) findViewById(R.id.zeit_editText1);

		von.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				selectTime(v);
			}
		});
		// clicklistener fuer Zeit bis
		EditText bis = (EditText) findViewById(R.id.zeit_editText2);

		bis.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				selectTime(v);
			}
		});

		// clicklistener fuer Datum von
		EditText von1 = (EditText) findViewById(R.id.datum_editText1);

		von1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				selectDate(v);
			}
		});

		// clicklistener fuer datum bis
		EditText bis1 = (EditText) findViewById(R.id.datum_editText2);

		bis1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				selectDate(v);
			}
		});

		// checkbox on click
		CheckBox check = (CheckBox) findViewById(R.id.ganztaegig_checkbox);

		check.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {

				EditText z1 = (EditText) findViewById(R.id.zeit_editText1);
				EditText z2 = (EditText) findViewById(R.id.zeit_editText2);

				if (isChecked) {

					z1.setText(R.string.ganztaegig);
					z2.setText(R.string.ganztaegig);
					z1.setEnabled(false);
					z2.setEnabled(false);
					appointment.setAllday(true);
					appointment.getStarttime().setHour(0);
					appointment.getStarttime().setMinute(0);
					appointment.getEndtime().setHour(23);
					appointment.getEndtime().setMinute(59);

				} else {
					z1.setText(null);
					z2.setText(null);
					z1.setEnabled(true);
					z2.setEnabled(true);
					appointment.setAllday(false);

				}
			}
		});

		// erinnerungsbutton aktivieren
		Button erinnerung = (Button) findViewById(R.id.erinnernung_Button);
		erinnerung.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				selectReminder();

			}
		});

		Button w = (Button) findViewById(R.id.wiederholung_Button);
		w.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				selectRepeat();

			}
		});

	}

	/**
	 * Ueberprueft ob alle wichtigen Terminangaben gemacht wurden
	 * 
	 * @param view
	 *            Bestaetigungsbutton
	 */
	public void checkAppointment(View view) {

		EditText name = (EditText) findViewById(R.id.name_editText1);
		EditText startdate = (EditText) findViewById(R.id.datum_editText1);
		EditText enddate = (EditText) findViewById(R.id.datum_editText2);
		EditText starttime = (EditText) findViewById(R.id.zeit_editText1);
		EditText endtime = (EditText) findViewById(R.id.zeit_editText2);

		// abfrage ob alle angaben gemacht wurden
		if (appointment.isAllday() == false) {
			if (name.getText().length() != 0
					&& startdate.getText().length() != 0
					&& enddate.getText().length() != 0
					&& starttime.getText().length() != 0
					&& endtime.getText().length() != 0) {

				// termin setzen und beenden

				if (!MainActivity.getProfil().getKalenderListe().getFirst()
						.getAppointments().isEmpty()
						&& terminUeberschneidung(appointment)) {

					conflictWarning();
				} else {
					saveAppointment();
					finish();
				}
			} else {
				Toast.makeText(
						getApplicationContext(),
						"Fehlende Angaben im erstellten Termin! Bitte korregieren!",
						Toast.LENGTH_LONG).show();
			}
		} else {
			if (name.getText().length() != 0
					&& startdate.getText().length() != 0
					&& enddate.getText().length() != 0) {
				// termin setzen und beenden
				saveAppointment();
				finish();
			} else {
				Toast.makeText(
						getApplicationContext(),
						"Fehlende Angaben im erstellten Termin! Bitte korregieren!",
						Toast.LENGTH_LONG).show();
			}
		}
	}

	/**
	 * Bricht das Terminanlegen ab!
	 * 
	 * @param view
	 *            Abbruchbutton
	 */
	public void abort(View view) {

		if (this.getTitle().equals(getString(R.string.termin_bearbeiten))) {

			MainActivity.getProfil().getKalenderListe().getFirst()
					.getAppointments().add(appointmentBackup);

		}

		// termin loeschen
		appointment = null;
		// aktivity beenden
		finish();
	}

	/**
	 * setzt und speichert den Termin im Kalender
	 */
	public void saveAppointment() {
		// name setzen
		EditText name = (EditText) findViewById(R.id.name_editText1);
		String terminname = name.getText().toString();
		appointment.setName(terminname);

		// gewichtungen setzen
		appointment.setWeighting(new Weighting(carrer.getValue(), social
				.getValue(), body.getValue(), mind.getValue()));

		// beschreibung setzen
		EditText beschreibung = (EditText) findViewById(R.id.terminbeschreibung_editText);
		String terminbeschreibung = beschreibung.getText().toString();
		appointment.setDescription(terminbeschreibung);

		// ort setzen
		AutoCompleteTextView ort = (AutoCompleteTextView) findViewById(R.id.ort_editText);
		String ortsangabe = ort.getText().toString();
		appointment.setPlace(ortsangabe);

		// ort in liste fuer autocomplete speichern
		if (ortsangabe.length() > 0) {
			if (MainActivity.getProfil().getOrte().contains(ortsangabe)) {

				// keine speicherung
			} else {

				MainActivity.getProfil().getOrte().add(ortsangabe);

			}
		}

		// terminalarm setzen
		am = (AlarmManager) getSystemService(ALARM_SERVICE);

		// hat der termin eine wiederholung?
		if (appointment.getRepeat() > 0) {
			//setze serienID
			appointment.setSerienID();
		}

		// termin speichern

		// startdatum fuer serientermine
		DatePicker seriendatumstart = new DatePicker(this);
		seriendatumstart.updateDate(appointment.getStartdate().getYear(),
				appointment.getStartdate().getMonth(), appointment
						.getStartdate().getDay());

		// Enddatum fuer serientermine
		DatePicker seriendatumsende = new DatePicker(this);
		seriendatumsende.updateDate(appointment.getEnddate().getYear(),
				appointment.getEnddate().getMonth(), appointment.getEnddate()
						.getDay());

		// Ueberpruefen ob und welche wiederholung vorliegt
		switch (appointment.getRepeat()) {

		// einmaliger termin
		case 0:
			MainActivity.getProfil().getKalenderListe().getFirst()
					.getAppointments().add(appointment);

			setNotification(appointment.getReminder(),
					appointment.getStartInMillis(), appointment);
			break;

		// taeglicher termin
		case 1:

			MainActivity.getProfil().getKalenderListe().getFirst()
			.getAppointments().add(appointment);

			setNotification(appointment.getReminder(),
			appointment.getStartInMillis(), appointment);
			
			while (seriendatumstart.getYear() < 2015) {

				// datum aktuallisieren
				seriendatumstart.updateDate(seriendatumstart.getYear(),
						seriendatumstart.getMonth(),
						seriendatumstart.getDayOfMonth() + 1);
				seriendatumsende.updateDate(seriendatumsende.getYear(),
						seriendatumsende.getMonth(),
						seriendatumsende.getDayOfMonth() + 1);

				// termin startdatum aktualï¿œlisieren
				appointment.setStartdate(new Date(seriendatumstart
						.getDayOfMonth(), seriendatumstart.getMonth(),
						seriendatumstart.getYear()));
				appointment.setEnddate(new Date(seriendatumsende
						.getDayOfMonth(), seriendatumsende.getMonth(),
						seriendatumsende.getYear()));

				Appointment edit = new Appointment();

				// termin setzen
				MainActivity.getProfil().getKalenderListe().getFirst()
						.getAppointments().add(edit);
//				setNotification(edit.getReminder(), edit.getStartInMillis(),
//						edit);
			}
			break;

		// woechentlicher termin
		case 2:

			MainActivity.getProfil().getKalenderListe().getFirst()
			.getAppointments().add(appointment);

			setNotification(appointment.getReminder(),
			appointment.getStartInMillis(), appointment);

			while (seriendatumstart.getYear() < 2015) {

				// datum aktuallisieren
				seriendatumstart.updateDate(seriendatumstart.getYear(),
						seriendatumstart.getMonth(),
						seriendatumstart.getDayOfMonth() + 7);
				seriendatumsende.updateDate(seriendatumsende.getYear(),
						seriendatumsende.getMonth(),
						seriendatumsende.getDayOfMonth() + 7);

				// termin startdatum aktualï¿œlisieren
				appointment.setStartdate(new Date(seriendatumstart
						.getDayOfMonth(), seriendatumstart.getMonth(),
						seriendatumstart.getYear()));
				appointment.setEnddate(new Date(seriendatumsende
						.getDayOfMonth(), seriendatumsende.getMonth(),
						seriendatumsende.getYear()));

				Appointment edit = new Appointment(appointment);

				// termin setzen
				MainActivity.getProfil().getKalenderListe().getFirst()
						.getAppointments().add(edit);
//				setNotification(edit.getReminder(), edit.getStartInMillis(),
//						edit);
			}
			break;

		// monatlicher termin
		case 3:

			MainActivity.getProfil().getKalenderListe().getFirst()
			.getAppointments().add(appointment);

			setNotification(appointment.getReminder(),
			appointment.getStartInMillis(), appointment);

			while (seriendatumstart.getYear() < 2015) {

				// datum aktuallisieren
				seriendatumstart.updateDate(seriendatumstart.getYear(),
						seriendatumstart.getMonth() + 1,
						seriendatumstart.getDayOfMonth());
				seriendatumsende.updateDate(seriendatumsende.getYear(),
						seriendatumsende.getMonth() + 1,
						seriendatumsende.getDayOfMonth());

				// termin startdatum aktualï¿œlisieren
				appointment.setStartdate(new Date(seriendatumstart
						.getDayOfMonth(), seriendatumstart.getMonth(),
						seriendatumstart.getYear()));
				appointment.setEnddate(new Date(seriendatumsende
						.getDayOfMonth(), seriendatumsende.getMonth(),
						seriendatumsende.getYear()));

				Appointment edit = new Appointment(appointment);

				// termin setzen
				MainActivity.getProfil().getKalenderListe().getFirst()
						.getAppointments().add(edit);
//				setNotification(edit.getReminder(), edit.getStartInMillis(),
//						edit);
			}
			break;

		default:
			break;
		}
		// termin loeschen
		appointment = null;
	}

	/**
	 * Ueberprueft ob Startdatum <= Enddatum und korregiert gegebenenfalls
	 */
	public void checkDate() {

		// datepoicker zum festlegen des datums
		DatePicker date = (DatePicker) dlg_date.findViewById(R.id.DatePicker1);

		// Datum korregieren

		// wenn enddatum<startdatum
		if (appointment.getEnddate().compareTo(appointment.getStartdate()) < 0) {

			// wenn EndZeit < Startzeit
			if (appointment.getEndtime().compareTo(appointment.getStarttime()) < 0) {

				// Enddatum =Startdatum+1

				date.updateDate(date.getYear(), date.getMonth(),
						date.getDayOfMonth() + 1);
				appointment.getEnddate().setDay(date.getDayOfMonth());
				appointment.getEnddate().setMonth(date.getMonth());
				appointment.getEnddate().setYear(date.getYear());

				// datepicker wieder zuruecksetzen
				date.updateDate(appointment.getStartdate().getYear(),
						appointment.getStartdate().getMonth(), appointment
								.getStartdate().getDay());

			} else
				// TODO Rausfinden, was der Code macht. Wahrscheinlich muss hier
				// geklammert werden

				// setze enddatum=startdatum
				appointment.getEnddate().setYear(
						appointment.getStartdate().getYear());
			appointment.getEnddate().setMonth(
					appointment.getStartdate().getMonth());
			appointment.getEnddate()
					.setDay(appointment.getStartdate().getDay());

		}
	}

	/**
	 * laed alle Termindetails in die Activity um einen Termin bearbeiten zu
	 * koennen!
	 * 
	 */
	public void editAppointment() {

		this.setTitle(getString(R.string.termin_bearbeiten));

		EditText name = (EditText) findViewById(R.id.name_editText1);
		EditText startdate = (EditText) findViewById(R.id.datum_editText1);
		EditText enddate = (EditText) findViewById(R.id.datum_editText2);
		EditText starttime = (EditText) findViewById(R.id.zeit_editText1);
		EditText endtime = (EditText) findViewById(R.id.zeit_editText2);
		CheckBox check = (CheckBox) findViewById(R.id.ganztaegig_checkbox);
		Button repeat = (Button) findViewById(R.id.wiederholung_Button);
		Button reminder = (Button) findViewById(R.id.erinnernung_Button);
		EditText place = (EditText) findViewById(R.id.ort_editText);
		EditText description = (EditText) findViewById(R.id.terminbeschreibung_editText);

		// name setzen
		name.setText(appointment.getName());
		// datum setzen
		startdate.setText(appointment.getStartdate().toString());
		enddate.setText(appointment.getEnddate().toString());

		// Zeit setzen
		if (!appointment.isAllday()) {
			starttime.setText(appointment.getStarttime().toString());
			endtime.setText(appointment.getEndtime().toString());
		} else {
			// hier muss die checkbox bearbeitet werden
			starttime.setText(R.string.ganztaegig);
			endtime.setText(R.string.ganztaegig);
			starttime.setEnabled(false);
			endtime.setEnabled(false);
			check.setChecked(appointment.isAllday());
		}

		// gewichtung setzen
		carrer = new CalendarWeightingListitem(getString(R.string.beruf),
				appointment.getWeighting().getCarrer());
		body = new CalendarWeightingListitem(getString(R.string.koerper),
				appointment.getWeighting().getBody());
		mind = new CalendarWeightingListitem(getString(R.string.sinn),
				appointment.getWeighting().getMind());
		social = new CalendarWeightingListitem(getString(R.string.kontakt),
				appointment.getWeighting().getSocial());

		// wiederholung setzen

		repeat.setText(getResources().getStringArray(R.array.wiederholung)[appointment
				.getRepeat()]);

		// erinnerung setzen
		reminder.setText(getResources().getStringArray(R.array.erinnerung)[appointment
				.getReminder()]);

		// ort setzen
		place.setText(appointment.getplace());

		// beschreibung setzen
		description.setText(appointment.getDescription());

		// alten termin aus der liste lï¿œschen
		LinkedList<Appointment> terminliste = new LinkedList<Appointment>();
		terminliste.addAll(MainActivity.getProfil().getKalenderListe()
				.getFirst().getAppointments());

		for (Appointment t : terminliste) {

			if (appointment.getId() == t.getId()) {

				MainActivity.getProfil().getKalenderListe().getFirst()
						.getAppointments().remove(t);
			}
		}
	}

	/**
	 * Baut einen Dialog auf, in dem man die Wiederholung des Termines festlegen
	 * kann!
	 * 
	 */
	public void selectRepeat() {

		// dialog aufbauen
		dlg_repeat = new Dialog(this);

		dlg_repeat.setContentView(R.layout.termin_wiederholung);
		dlg_repeat.setTitle("Wiederholung");
		dlg_repeat.show();
		// Dialoggrï¿œï¿œe setzen
		WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
		lp.copyFrom(dlg_repeat.getWindow().getAttributes());
		lp.width = 470;
		lp.height = 600;
		lp.x = -170;
		lp.y = 50;
		dlg_repeat.getWindow().setAttributes(lp);

		// Dialog fuellen

		final ListView list = (ListView) dlg_repeat
				.findViewById(R.id.terminwiederholungListView1);
		list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

		Button ok = (Button) dlg_repeat
				.findViewById(R.id.termin_wiederholung_ok_button);
		Button abbruch = (Button) dlg_repeat
				.findViewById(R.id.termin_wiederholung_abbruch_button);

		list.setAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_single_choice, getResources()
						.getStringArray(R.array.wiederholung)));

		// einstellung laden
		list.setItemChecked(appointment.getRepeat(), true);

		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				switch (position) {

				case 0:

					if (view.isPressed()) {
						view.setPressed(false);
					} else
						view.setPressed(true);

					break;

				}

			}

		});

		ok.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				int pos = list.getCheckedItemPosition();

				// auswahl speichern
				appointment.setRepeat(pos);
				// Buttontext festlegen
				Button akt = (Button) findViewById(R.id.wiederholung_Button);
				akt.setText(getResources().getStringArray(R.array.wiederholung)[pos]);
				// dialog schließen
				dlg_repeat.dismiss();

			}
		});

		abbruch.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				dlg_repeat.dismiss();
			}
		});

	}

	/**
	 * Baut einen Dialog auf, welcher den Nutzer bei Terminueberschneidung
	 * warnt!
	 */
	public void conflictWarning() {

		// Dialog aufbauen
		dlg_conflict = new Dialog(this);

		dlg_conflict.setContentView(R.layout.terminueberschneidung);
		dlg_conflict.setTitle("Achtung Terminkollision !");
		dlg_conflict.show();

		TextView aktTerminName = (TextView) dlg_conflict
				.findViewById(R.id.kollisionTerminName);
		TextView aktTerminDetail = (TextView) dlg_conflict
				.findViewById(R.id.kollisionTerminDetail);

		EditText name = (EditText) findViewById(R.id.name_editText1);
		String terminname = name.getText().toString();
		EditText datum = (EditText) findViewById(R.id.datum_editText1);
		String termindatum = datum.getText().toString();
		EditText startzeit = (EditText) findViewById(R.id.zeit_editText1);
		String terminstart = startzeit.getText().toString();

		aktTerminName.setText(terminname);
		aktTerminDetail.setText(termindatum + ", " + terminstart + " Uhr");

		// Liste mit kollisionsterminen fuellen
		ArrayList<AppointmentConflictListItem> terminliste = new ArrayList<AppointmentConflictListItem>();

		for (Appointment t : conflictAppointments) {

			String termin = t.getStartdate().toString() + ", "
					+ t.getStarttime().toString() + " - "
					+ t.getEndtime().toString();

			terminliste
					.add(new AppointmentConflictListItem(t.getName(), termin));
		}

		final ListView menueList = (ListView) dlg_conflict
				.findViewById(R.id.kollisionTerminListe);

		menueList.setAdapter(new AppointmentConflictListItemAdapter(this,
				R.layout.kollisionstermin, terminliste));

		Button ignorieren = (Button) dlg_conflict.findViewById(R.id.ignorieren);
		Button aendern = (Button) dlg_conflict.findViewById(R.id.aendern);

		ignorieren.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dlg_conflict.dismiss();
				saveAppointment();
				finish();

			}
		});

		aendern.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dlg_conflict.dismiss();
			}
		});

	}

	/**
	 * Baut einen Dialog zur Terminerinnerungsauswahl auf
	 */

	public void selectReminder() {

		dlg_reminder = new Dialog(this);

		dlg_reminder.setContentView(R.layout.termin_erinnerung);
		dlg_reminder.setTitle("Erinnerung");
		dlg_reminder.show();
		// Dialoggrï¿œï¿œe setzen
		WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
		lp.copyFrom(dlg_reminder.getWindow().getAttributes());
		lp.width = 470;
		lp.height = 600;
		lp.x = -170;
		lp.y = 50;
		dlg_reminder.getWindow().setAttributes(lp);

		// Dialog fuellen
		final ListView list = (ListView) dlg_reminder
				.findViewById(R.id.terminerinnerungsListView1);
		list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

		Button ok = (Button) dlg_reminder
				.findViewById(R.id.termin_erinnerung_ok_button);
		Button abbruch = (Button) dlg_reminder
				.findViewById(R.id.termin_erinnerung_abbruch_button);

		list.setAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_single_choice, getResources()
						.getStringArray(R.array.erinnerung)));

		// einstellung laden
		list.setItemChecked(appointment.getReminder(), true);

		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				switch (position) {

				case 0:

					if (view.isPressed()) {
						view.setPressed(false);
					} else
						view.setPressed(true);

					break;

				}

			}

		});

		ok.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				int pos = list.getCheckedItemPosition();

				// auswahl speichern
				appointment.setReminder(pos);

				Button akt = (Button) findViewById(R.id.erinnernung_Button);
				akt.setText(getResources().getStringArray(R.array.erinnerung)[pos]);
				dlg_reminder.dismiss();

			}
		});

		abbruch.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dlg_reminder.dismiss();
			}
		});
	}

	/**
	 * @return the termin
	 */
	public static Appointment getAppointment() {
		return appointment;
	}

	/**
	 * @param appointment
	 *            the termin to set
	 */
	public static void setAppointment(Appointment ap) {
		appointment = ap;
	}

	/**
	 * erstellt eine Notification
	 * 
	 * @param er
	 *            , der Erinnerungsfaktor(Zeit)
	 * @param starttime
	 *            , gibt die Startzeit des Termins an
	 * @param t
	 *            , der Termin welcher eine Notification erhaelt
	 */
	public void setNotification(int er, long starttime, Appointment t) {

		// wenn erinnerung gesetzt
		if (er > 0) {

			// Intentuebergabe an den receiver
			Intent intent = new Intent(this, AlarmReceiver.class);
			intent.putExtra("id", t.getId());
			intent.putExtra("name", t.getName());
			intent.putExtra("startDate", t.getStartdate().toString());
			intent.putExtra("startTime", t.getStarttime().toString());

			PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0,
					intent, PendingIntent.FLAG_ONE_SHOT);

			switch (er) {

			case 1:

				am.set(AlarmManager.RTC_WAKEUP, starttime - 1000 * 60 * 10,
						pendingIntent);

				break;

			case 2:
				am.set(AlarmManager.RTC_WAKEUP, starttime - 1000 * 60 * 30,
						pendingIntent);
				break;

			case 3:
				am.set(AlarmManager.RTC_WAKEUP, starttime - 1000 * 60 * 60,
						pendingIntent);

				break;

			case 4:
				am.set(AlarmManager.RTC_WAKEUP, starttime - 1000 * 60 * 60 * 2,
						pendingIntent);
				break;

			}
		}

	}

	/**
	 * 
	 * @param a
	 *            ist der Eingabetermin welcher auf kollision überprüft wird
	 * @return true wenn eine kollision vorhanden ist
	 * 
	 */

	public boolean terminUeberschneidung(Appointment a) {

		conflictAppointments = new LinkedList<Appointment>();

		boolean erg = false;

		for (Appointment iter : MainActivity.getProfil().getKalenderListe()
				.getFirst().getAppointments()) {

			erg = false;

			if (a.getStartInMinutes() > iter.getStartInMinutes()
					&& a.getStartInMinutes() < iter.getEndInMinutes()) {

				erg = true;
			} else

			if (iter.getStartInMinutes() > a.getStartInMinutes()
					&& iter.getStartInMinutes() < a.getEndInMinutes()) {

				erg = true;
			} else

			if (a.getEndInMinutes() > iter.getStartInMinutes()
					&& a.getEndInMinutes() < iter.getEndInMinutes()) {

				erg = true;
			} else

			if (iter.getEndInMinutes() > a.getStartInMinutes()
					&& iter.getEndInMinutes() < a.getEndInMinutes()) {

				erg = true;
			}
			if (erg) {
				conflictAppointments.add(iter);
			}
		}

		return (conflictAppointments.size() > 0);
	}

	/**
	 * abfrage ob termin abgebrochen werden soll!
	 */
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {

			dlg_abort = new Dialog(this);
			dlg_abort.setTitle("Termin abbrechen ?");
			dlg_abort.setContentView(R.layout.termin_abbrechen);
			dlg_abort.show();

			final Button ja = (Button) dlg_abort
					.findViewById(R.id.termin_abbrechen_ja_button);
			final Button nein = (Button) dlg_abort
					.findViewById(R.id.termin_abbrechen_nein_button);

			ja.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {

					dlg_abort.dismiss();
					abort(ja);
				}
			});

			nein.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {

					dlg_abort.dismiss();

				}
			});

			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	/**
	 * @return the menuePoints
	 */
	public ArrayList<CalendarWeightingListitem> getMenuePoints() {
		return menuePoints;
	}

}
