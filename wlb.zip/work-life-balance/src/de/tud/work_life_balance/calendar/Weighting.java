package de.tud.work_life_balance.calendar;

import java.io.Serializable;

/**
 * Die Gewichtung der Bereiche
 * @author Matthias Conrad
 *
 */
public class Weighting implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	// Gewichtungen
    private int carrer, social, body, mind;
    
    /**
     * Konstruktor mit Angabe der Gewichtungsverteilung
     * @param carrer
     * @param social
     * @param body
     * @param mind
     */

	public Weighting(int carrer, int social, int body, int mind) {
		super();
		this.carrer = carrer;
		this.social = social;
		this.body = body;
		this.mind = mind;
	}

	
	/**
	 * Konstruktor ohne Angabe der Gewichtungsverteilung
	 */
	public Weighting() {
		super();
		this.carrer = 0;
		this.social = 0;
		this.body = 0;
		this.mind = 0;
	}

	/**
	 * @return the beruf
	 */
	public int getCarrer() {
		return carrer;
	}

	/**
	 * @return the kontakt
	 */
	public int getSocial() {
		return social;
	}

	/**
	 * @return the koerper
	 */
	public int getBody() {
		return body;
	}

	/**
	 * @return the sinn
	 */
	public int getMind() {
		return mind;
	}

	/**
	 * @param carrer the beruf to set
	 */
	public void setCarrer(int carrer) {
		this.carrer = carrer;
	}

	/**
	 * @param social the kontakt to set
	 */
	public void setSocial(int social) {
		this.social = social;
	}

	/**
	 * @param body the koerper to set
	 */
	public void setBody(int body) {
		this.body = body;
	}

	/**
	 * @param mind the sinn to set
	 */
	public void setMind(int mind) {
		this.mind = mind;
	}

}
