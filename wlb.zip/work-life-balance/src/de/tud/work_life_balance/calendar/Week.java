package de.tud.work_life_balance.calendar;

//TODO wird die klasse benötigt -> Wenn nicht - löschen
public class Week {

}
