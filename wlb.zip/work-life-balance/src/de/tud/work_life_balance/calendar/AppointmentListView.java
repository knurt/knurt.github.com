package de.tud.work_life_balance.calendar;

import java.util.SortedSet;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import de.tud.work_life_balance.R;

/**
 * Diese Klasse stellt eine neue View zur Verfuegung, die Termine in einer vertikalen
 * Liste anzeigt.
 */
public class AppointmentListView extends LinearLayout {
	public static final String APPOINTMENT_ID = "de.tud.work_life_balance.APPOINTMENT_ID";

	public AppointmentListView(Context context) {
		super(context);
	}

	public AppointmentListView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public AppointmentListView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	public void updateAppointmentList(final Activity parent, Calendar calendar, long startMillis, long endMillis) {
		removeAllViews();
		SortedSet<Appointment> appos = calendar.getAppointmentsBetween(startMillis, endMillis);
		TextView tv = null;
		
		for (Appointment appo : appos) {
			tv = new TextView(this.getContext());
			tv.setText(String.format("von\t%s %s\nbis\t%s %s\n\n\t\t%s",
					appo.getStartdate(),
					appo.getStarttime(),
					appo.getEnddate(),
					appo.getEndtime(),
					appo.getName()));
			tv.setBackgroundColor(getResources().getColor(R.color.android_light_blue));
			tv.setTextSize(15);

			LayoutParams lp = new LinearLayout.LayoutParams(
					LayoutParams.MATCH_PARENT,
					LayoutParams.WRAP_CONTENT);
			lp.setMargins(5, 5, 5, 5);
			tv.setLayoutParams(lp);

			final Appointment appointmentConnectedToClick = appo;
			tv.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					Context context = (AppointmentListView.this).getContext();
					Intent intent = new Intent(context,
							ShowAppointment.class);
					intent.putExtra(APPOINTMENT_ID,
							appointmentConnectedToClick.getId());
					parent.startActivityForResult(intent, 0);
				}
			});
			addView(tv);
		}
	}
}
