package de.tud.work_life_balance.calendar;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.SortedSet;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import de.tud.work_life_balance.MainActivity;
import de.tud.work_life_balance.R;

/**
 * Diese Klasse baut eine Activity auf, welche ein Termin anzeigt!
 * 
 * @author Matthias Conrad
 */
public class ShowAppointment extends Activity {

	private Appointment appointment = null;

	private Dialog dlg_repeat;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_calender_termin_anzeigen);

		final ActionBar actionBar = getActionBar();
		actionBar.setDisplayHomeAsUpEnabled(true);

		Intent intent = getIntent();
		long terminId = intent.getLongExtra(
				CalendarOverviewActivity.APPOINTMENT_ID, -1);
		SortedSet<Appointment> terminliste = MainActivity.getProfil()
				.getKalenderListe().getFirst().getAppointments();
		for (Appointment t : terminliste) {
			if (t.getId() == terminId) {
				appointment = t;
				break;
			}
		}
		if (appointment == null) {
			finish();
		}

		setAppointment();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_calender_termin_anzeigen,
				menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// app icon in action bar clicked; go home
			finish();
			return true;

		case R.id.termin_loeschen:
			if (appointment.getSerienID() > 0) {
				deleteRepeatingAppointment();
			} else {
				deleteAppointment(0);
			}
			return true;

		case R.id.termin_bearbeiten:
			CreateAppointment.setAppointment(appointment);
			startActivity(new Intent(this, CreateAppointment.class));
			finish();
			return true;

		default:
			return super.onOptionsItemSelected(item);
		}
	}

	/**
	 * f�llt die Activity mit dem Termin
	 */
	public void setAppointment() {

		TextView datum = (TextView) findViewById(R.id.termin_anzeigen_datum);
		TextView name = (TextView) findViewById(R.id.termin_anzeigen_name);
		TextView zeit = (TextView) findViewById(R.id.termin_anzeigen_zeit);
		TextView beschreibung = (TextView) findViewById(R.id.termin_anzeigen_beschreibung);
		TextView ort = (TextView) findViewById(R.id.termin_anzeigen_ort);
		TextView wiederholung = (TextView) findViewById(R.id.termin_anzeigen_wiederholung);
		TextView erinnerung = (TextView) findViewById(R.id.termin_anzeigen_erinnerung);

		// name setzen
		name.setText(appointment.getName());

		// zeit setzen
		if (appointment.isAllday()) {
			zeit.setText(getString(R.string.ganztaegig));
		} else {
			zeit.setText(appointment.getStarttime().toString() + " Uhr "
					+ " -  " + appointment.getEndtime().toString() + " Uhr");
		}

		// datum setzen
		if (appointment.getStartdate().toString()
				.equals(appointment.getEnddate().toString())) {
			datum.setText(appointment.getStartdate().toString());
		} else {
			if (appointment.isAllday()) {
				datum.setText(appointment.getStartdate() + " - "
						+ appointment.getEnddate());
			} else {
				zeit.setText(appointment.getStartdate().toString() + ", "
						+ appointment.getStarttime().toString() + " Uhr -");
				datum.setText(appointment.getEnddate().toString() + ", "
						+ appointment.getEndtime().toString() + " Uhr");
			}
		}

		// ort setzen
		ort.setText(appointment.getplace());

		// erinnerung setzen
		erinnerung
				.setText(getResources().getStringArray(R.array.erinnerung)[appointment
						.getReminder()]);

		// wiederholung setzen
		wiederholung.setText(getResources()
				.getStringArray(R.array.wiederholung)[appointment.getRepeat()]);

		// beschreibung setzen

		beschreibung.setText(appointment.getDescription());

		// gewichtung setzen
		ArrayList<CalendarWeightingListitem> menuePoints = new ArrayList<CalendarWeightingListitem>();

		// gewichtungselemente
		CalendarWeightingListitem beruf_g = new CalendarWeightingListitem(
				getString(R.string.beruf), appointment.getWeighting()
						.getCarrer());
		CalendarWeightingListitem koerper_g = new CalendarWeightingListitem(
				getString(R.string.koerper), appointment.getWeighting()
						.getBody());
		CalendarWeightingListitem sinn_g = new CalendarWeightingListitem(
				getString(R.string.sinn), appointment.getWeighting().getMind());
		CalendarWeightingListitem kontakt_g = new CalendarWeightingListitem(
				getString(R.string.kontakt), appointment.getWeighting()
						.getSocial());

		// gewichtung hinzuf�gen
		menuePoints.add(beruf_g);
		menuePoints.add(koerper_g);
		menuePoints.add(sinn_g);
		menuePoints.add(kontakt_g);

		// listview adapter zuweisen
		ListView menueList = (ListView) findViewById(R.id.termin_anzeigen_gewichtung);

		CalendarWeightingItemAdapter adapter = new CalendarWeightingItemAdapter(
				this, R.layout.kalender_gewichtungs_listitem2, menuePoints);
		menueList.setAdapter(adapter);
	}

	/**
	 * Baut ein Dialog auf, welcher beim l�schen eines SerienTermins abfr�gt was
	 * gel�scht werden soll!
	 */
	public void deleteRepeatingAppointment() {

		dlg_repeat = new Dialog(this);

		dlg_repeat.setContentView(R.layout.serientermin_loeschen);
		dlg_repeat.setTitle(getString(R.string.serientermin_loeschen));

		dlg_repeat.show();

		// Dialoggroe�e setzen
		WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
		lp.copyFrom(dlg_repeat.getWindow().getAttributes());
		lp.width = 470;
		lp.height = 500;
		// lp.x=-170;
		// lp.y=50;
		dlg_repeat.getWindow().setAttributes(lp);

		// Dialog fuellen
		final ListView list = (ListView) dlg_repeat
				.findViewById(R.id.serienterminListView1);
		list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

		Button ok = (Button) dlg_repeat
				.findViewById(R.id.serientermin_ok_button);
		Button abbruch = (Button) dlg_repeat
				.findViewById(R.id.serientermin_abbruch_button);

		list.setAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_single_choice, getResources()
						.getStringArray(R.array.serientermin)));

		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				switch (position) {

				case 0:

					if (view.isPressed()) {
						view.setPressed(false);
					} else
						view.setPressed(true);

					break;

				}

			}

		});

		ok.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				int pos = list.getCheckedItemPosition();

				dlg_repeat.dismiss();

				if (pos == 0) {

					// alle serientermine l�schen
					deleteAppointment(1);
				} else {

					// termin l�schen
					deleteAppointment(0);
				}

			}
		});

		abbruch.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dlg_repeat.dismiss();
			}
		});

	}

	/**
	 * Baut ein Dialog auf, welcher beim löschen eines Termins abfragt ob
	 * wirklich gelöscht werden soll!
	 */
	public void deleteAppointment(final int del) {
		// TODO evtl(!) "del" durch "serialId" ersetzen

		// termin wirklich löschen
		Dialog delete = new Dialog(this);
		delete.setContentView(R.layout.termin_loeschen);
		TextView t = (TextView) delete
				.findViewById(R.id.termin_loeschen_textView);
		if (del == 0) {
			delete.setTitle(getString(R.string.termin_loeschen));
			// termindetails setzen
			t.setText(appointment.getName() + ", " + appointment.getStartdate()
					+ ", " + appointment.getStarttime() + " Uhr");
		} else {
			// TODO string extrahieren
			delete.setTitle(getString(R.string.serientermin_loeschen));
			// termindetails setzen
			t.setText(appointment.getName());
		}
		delete.show();

		Button ok = (Button) delete.findViewById(R.id.button1);
		ok.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				LinkedList<Appointment> terminliste = new LinkedList<Appointment>();
				terminliste.addAll(MainActivity.getProfil().getKalenderListe()
						.getFirst().getAppointments());

				// wenn einzeltermin dann
				if (del == 0) {
					for (Appointment t : terminliste) {
						if (appointment.getId() == t.getId()) {
							MainActivity.getProfil().getKalenderListe()
									.getFirst().getAppointments().remove(t);
						}
					}
					Toast.makeText(getApplicationContext(),
							getString(R.string.termin_wurde_geloescht),
							Toast.LENGTH_LONG).show();

				} else {
					// ansonsten (serientermin)

					for (Appointment t : terminliste) {
						if (appointment.getSerienID() == t.getSerienID()) {
							MainActivity.getProfil().getKalenderListe()
									.getFirst().getAppointments().remove(t);
						}
					}
					Toast.makeText(getApplicationContext(),
							getString(R.string.serientermin_geloescht),
							Toast.LENGTH_LONG).show();
				}

				finish();
			}
		});

		Button abbrechen = (Button) delete.findViewById(R.id.button2);
		abbrechen.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
	}

	/**
	 * @return the appointment
	 */
	public Appointment getAppointment() {
		return appointment;
	}

	/**
	 * @param appointment
	 *            the appointment to set
	 *            TODO wird die Methode irgendwo
	 *            verwendet?
	 */
	public void setAppointment(Appointment appointment) {
		this.appointment = appointment;
	}

}
