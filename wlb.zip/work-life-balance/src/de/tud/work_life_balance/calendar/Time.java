package de.tud.work_life_balance.calendar;

import java.io.Serializable;

/**
 * Diese Klasse stellt einen Zeitpunkt an einem Tag dar,
 * bestehend aus einer Stunde und einer Minute.
 *
 */
public class Time implements Comparable<Time>, Serializable {

	private static final long serialVersionUID = 1L;
	private int hour, minute;

	public Time(int stunde, int minute) {
		super();
		this.hour = stunde;
		this.minute = minute;
	}

	public Time() {
		super();
		this.hour = 0;
		this.minute = 0;
	}

	/**
	 * @return the stunde
	 */
	public int getHour() {
		return hour;
	}

	/**
	 * @return the minute
	 */
	public int getMinute() {
		return minute;
	}

	/**
	 * @param hour
	 *            the stunde to set
	 */
	public void setHour(int hour) {
		this.hour = hour;
	}

	/**
	 * @param minute
	 *            the minute to set
	 */
	public void setMinute(int minute) {
		this.minute = minute;
	}

	
	/**
	 * @return Die Zeit als String
	 */
	public String toString() {

		if (minute < 10) {

			return String.format("%d:%d%d", hour, 0, minute);
		} else {

			return String.format("%d:%d", hour, minute);
		}
	}

	/**
	 * Vergleicht zwei Zeiten miteinander
	 */
	
	@Override
	public int compareTo(Time other) {
		int hourComparison = Integer.valueOf(this.hour).compareTo(other.hour);

		if (hourComparison != 0) {
			return hourComparison;
		} else {
			int minuteComparison = Integer.valueOf(this.minute).compareTo(other.minute);
			if (minuteComparison != 0) {
				return minuteComparison;
			} else {
				// Es darf nur 0 ausgegeben werden, wenn die Objekte gleich sind
				if (this.equals(other)) {
					return 0;
				} else {
					return 1;
				}
			}
		}
	}
}
