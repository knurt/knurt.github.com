package de.tud.work_life_balance.calendar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;
import de.tud.work_life_balance.MainActivity;
import de.tud.work_life_balance.R;
import de.tud.work_life_balance.TagesViewActivity;
import de.tud.work_life_balance.Util;

/**
 * 
 * @author Felix Mueller
 * 
 */
public class CalendarOverviewActivity extends Activity {

	private TabHost tabHost;
	private LinearLayout llDayAppointments;
	private LinearLayout[] llWeekAppointments;
	private AppointmentListView llAppointments;
	private AppointmentListView llDayInMonth;
	private TextView tvDate;
	private Calendar calendar;
	// aktuell ausgewaehlter Tag, muss nicht unbedingt heute sein:
	private Date today;
	private ScrollView svTabDay;
	private ScrollView svWeek;
	private Button btnBackward;
	private Button btnForward;
	private TextView tvMonthName;
	private GridView gvMonth;
	private CalendarAdapter adapter;

	private static final String[] MONTH_NAMES = new String[] { "Januar",
			"Februar", "März", "April", "Mai", "Juni", "Juli", "August",
			"September", "Oktober", "November", "Dezember" };
	private static final int PIXEL_PER_MINUTE = 1; // TODO evtl durch
													// "MILLIS_PER_PIXEL = 1000"
													// ersetzen
	public static final String APPOINTMENT_ID = "de.tud.work_life_balance.APPOINTMENT_ID";

	@Override
	protected final void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_calendar_overview);

		final ActionBar actionBar = getActionBar();
		actionBar.setDisplayHomeAsUpEnabled(true);

		llDayAppointments = (LinearLayout) findViewById(R.id.llDayAppointments);
		llWeekAppointments = new LinearLayout[7];
		int[] weekIDs = { R.id.llMondayAppointments,
				R.id.llTuesdayAppointments, R.id.llWednesdayAppointments,
				R.id.llThursdayAppointments, R.id.llFridayAppointments,
				R.id.llSaturdayAppointments, R.id.llSundayAppointments };
		for (int i = 0; i < 7; ++i) {
			llWeekAppointments[i] = (LinearLayout) findViewById(weekIDs[i]);
		}
		llAppointments = (AppointmentListView) findViewById(R.id.llAppointments);
		llDayInMonth = (AppointmentListView) findViewById(R.id.llDayInMonth);

		svTabDay = (ScrollView) findViewById(R.id.svTabDay);
		svWeek = (ScrollView) findViewById(R.id.svWeek);

		// Kalender anlegen bzw. holen
		calendar = MainActivity.getProfil().getKalenderListe().getFirst();

		today = new Date(GregorianCalendar.getInstance());

		tabHost = (TabHost) findViewById(R.id.tabhost);

		gvMonth = (GridView) findViewById(R.id.gvMonth);
		adapter = new CalendarAdapter(this, today.getCalendarFormat(), calendar);
		gvMonth.setAdapter(adapter);

		gvMonth.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(final AdapterView<?> parent, final View v,
					final int position, final long id) {
				if (adapter.posIsDay(position)) {
					adapter.setSelectedDay(position);
					today = new Date(adapter.getSelectedDate());
					tvDate.setText(DateFormat.format("E, dd.MM.yyyy",
							today.getTimeInMillis()));
					updateDayAppointments(svTabDay, llDayAppointments, today,
							false);
					updateDayInMonth();
					adapter.notifyDataSetChanged();
				}
			}
		});

		gvMonth.setOnItemLongClickListener(new OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(final AdapterView<?> parent,
					final View v, final int position, final long id) {
				adapter.setSelectedDay(position);
				adapter.notifyDataSetChanged();
				today = new Date(adapter.getSelectedDate());
				updateDayAppointments(svTabDay, llDayAppointments, today, false);
				tabHost.setCurrentTab(0); // Tagesansicht auswaehlen
				tvDate.setText(DateFormat.format("E, dd.MM.yyyy",
						today.getTimeInMillis()));
				return true;
			}
		});

		tvMonthName = (TextView) findViewById(R.id.tvMonthName);
		tvMonthName.setText(MONTH_NAMES[today.getMonth()]);

		btnForward = (Button) findViewById(R.id.btnForward);
		btnForward.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(final View v) {
				int month = adapter.addToMonth(1);
				tvMonthName.setText(MONTH_NAMES[month]);
				adapter.notifyDataSetChanged();
			}
		});

		btnBackward = (Button) findViewById(R.id.btnBackward);
		btnBackward.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(final View v) {
				int month = adapter.addToMonth(-1);
				tvMonthName.setText(MONTH_NAMES[month]);
				adapter.notifyDataSetChanged();
			}
		});

		setupTabs();
		drawTimeScale();
		drawCalendarContents();

		tvDate = (TextView) findViewById(R.id.tvDate);

		setTitle(""); // kein Titel, damit mehr Platz fuer Buttons ist
		tvDate.setText(DateFormat.format("E, dd.MM.yyyy",
				today.getTimeInMillis()));
	}

	@Override
	public final boolean onOptionsItemSelected(final MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// App-Icon angeklickt: Zurück in den Hauptbildschirm
			Intent intent = new Intent(this, MainActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent);
			return true;

		case R.id.openDayView:
			Intent oDV = new Intent(this, TagesViewActivity.class);
			startActivity(oDV);

		default:
			return super.onOptionsItemSelected(item);
		}
	}

	public final boolean onNewAppointmentClick(final MenuItem item) {
		Intent intent = new Intent(CalendarOverviewActivity.this,
				de.tud.work_life_balance.calendar.CreateAppointment.class);
		startActivityForResult(intent, 0);
		return true;
	}

	public final boolean onStopwatchClick(final MenuItem item) {
		Util.showUnimplementedToast(this);
		return true;
	}

	public final boolean onTodoClick(final MenuItem item) {
		Util.showUnimplementedToast(this);
		return true;
	}

	@Override
	public final boolean onCreateOptionsMenu(final Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_calendar_overview, menu);
		return true;
	}

	@Override
	protected final void onActivityResult(final int requestCode,
			final int resultCode, final Intent data) {
		drawCalendarContents();
		adapter.notifyDataSetChanged();
	}

	private void setupTabs() {
		tabHost.setup();
		TabSpec spec = tabHost.newTabSpec("spec1");
		spec.setContent(R.id.svTabDay);
		spec.setIndicator("Tag");
		tabHost.addTab(spec);
		spec = tabHost.newTabSpec("spec2");
		spec.setContent(R.id.llTabOuterWeek);
		spec.setIndicator("Woche");
		tabHost.addTab(spec);
		spec = tabHost.newTabSpec("spec3");
		spec.setContent(R.id.llTabMonth);
		spec.setIndicator("Monat");
		tabHost.addTab(spec);
		spec = tabHost.newTabSpec("spec4");
		spec.setContent(R.id.svTabAppointments);
		spec.setIndicator("Liste");
		tabHost.addTab(spec);
	}

	private void drawTimeScale() {
		LinearLayout llDay = (LinearLayout) findViewById(R.id.llTimescaleDay);
		LinearLayout llWeek = (LinearLayout) findViewById(R.id.llTimescaleWeek);

		for (LinearLayout ll : new LinearLayout[] { llDay, llWeek }) {
			TextView tvTime;
			for (int i = 0; i < 24; ++i) {
				tvTime = new TextView(this);
				String formatString = "%02d:00";
				if (ll.getId() == R.id.llTimescaleWeek) {
					formatString = "%02d";
				}
				tvTime.setText(String.format(formatString, i));
				tvTime.setTextSize(18.0f);
				tvTime.setGravity(Gravity.CENTER_HORIZONTAL);
				tvTime.setHeight(60 * PIXEL_PER_MINUTE);
				if (i % 2 == 0) {
					tvTime.setBackgroundColor(Color.WHITE);
				} else {
					tvTime.setBackgroundColor(Color.LTGRAY);
				}
				ll.addView(tvTime);
			}
		}
	}

	private void drawCalendarContents() {
		updateDayAppointments(svTabDay, llDayAppointments, today, false);

		int dayOfWeek = today.getCalendarFormat().get(
				java.util.Calendar.DAY_OF_WEEK);
		// Sonntag ist 1 - Samstag 7
		// Nach Transformation: Montag ist 0 - Sonntag 6
		dayOfWeek = (dayOfWeek + 5) % 7;
		for (int i = 0; i < llWeekAppointments.length; ++i) {
			java.util.Calendar day = today.getCalendarFormat();
			day.add(java.util.Calendar.DAY_OF_YEAR, i - dayOfWeek);
			updateDayAppointments(svWeek, llWeekAppointments[i], new Date(day),
					true);
		}

		updateAppointmentList();
		updateDayInMonth();
	}

	private void updateAppointmentList() {
		llAppointments.updateAppointmentList(this, calendar,
				System.currentTimeMillis(), Long.MAX_VALUE);
	}

	private void updateDayInMonth() {
		java.util.Calendar c = adapter.getSelectedDate();
		long startMillis = c.getTimeInMillis();
		c.add(java.util.Calendar.DAY_OF_YEAR, 1);
		long endMillis = c.getTimeInMillis();

		llDayInMonth.updateAppointmentList(this, calendar, startMillis,
				endMillis);
	}

	/**
	 * Fuellt das &uuml;bergebene LinearLayout mit der grafischen
	 * Repr&auml;sentation von Terminen, die an einem bestimmten Tag
	 * stattfinden.
	 * 
	 * @param ll
	 * @param day
	 */
	private void updateDayAppointmentsAlt(final ScrollView sv,
			final LinearLayout ll, final Date day, final boolean smallFont) {
		// alte Termine aus dem LinearLayout loeschen:
		ll.removeAllViews();

		boolean firstAppointmentFound = false; // wird zum automatischen
												// runterscrollen gebraucht
		sv.scrollTo(0, 320); // TODO funktioniert nicht!?

		Iterator<Appointment> appointments = calendar.getAppointments()
				.iterator();
		if (!appointments.hasNext()) {
			// keine Termine eingetragen: fertig
			return;
		}

		// Finde den ersten Termin, der Heute aufhoert:
		Appointment lastCheckedAppointment = appointments.next();
		while (appointments.hasNext()
				&& lastCheckedAppointment.getEnddate().compareTo(day) == -1) {
			lastCheckedAppointment = appointments.next();
		}

		if (lastCheckedAppointment.getEnddate().compareTo(day) == -1
				|| lastCheckedAppointment.getStartdate().compareTo(day) == 1) {
			// alle Termine sind entweder nach, oder vor heute: fertig
			return;
		}
		// /////////////////////////////////////////////////////////////////////////
		// Termine zeichnen
		Appointment appointmentToDraw = lastCheckedAppointment;
		TextView tv = null;
		// Ende des zuletzt angezeigten Termins in Minuten nach 1970
		long lastEnd = day.getTimeInMillis() / Appointment.MILLIS_PER_MINUTE;

		boolean lastRight = false; // Bei Überschneidungen wird der erste Termin
									// rechts gezeichnet
		int halfWidth = ll.getWidth() / 2;
		TextView lastTv = null;

		while (true) { // Abbruchbedingung ist unten
			tv = new TextView(this);
			tv.setText(appointmentToDraw.getName());
			tv.setBackgroundColor(getResources().getColor(
					R.color.android_light_blue));
			tv.setTextSize(smallFont ? 10 : 15);

			// Erste und letzte Minute des aktuellen Termins
			// wird zur berechnung der Hoehe des TextViews
			// verwendet.
			long startToday = day.getTimeInMillis()
					/ Appointment.MILLIS_PER_MINUTE;
			long endToday = startToday + 24 * 60;
			int freeTime = 0;
			if (appointmentToDraw.isAllday()
					|| (startsBefore(appointmentToDraw, day) && endsAfter(
							appointmentToDraw, day))) {
				// Termin geht von oben bis unten:
				// Werte bleiben, wie oben angegeben.
			} else {
				if (!startsBefore(appointmentToDraw, day)) {
					// Termin faengt nach 00:00 an
					startToday = appointmentToDraw.getStartInMinutes();
					freeTime = (int) (startToday - lastEnd);
				}

				if (!endsAfter(appointmentToDraw, day)) {
					// Termin endet vor 00:00
					endToday = appointmentToDraw.getEndInMinutes();
					lastEnd = endToday;
				}
			}
			int height = (int) (endToday - startToday) * PIXEL_PER_MINUTE;
			int space = (freeTime + 1) * PIXEL_PER_MINUTE;
			LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
					LayoutParams.MATCH_PARENT, height);

			if (freeTime >= 0) {
				lp.setMargins(5, space, 5, 0);
			} else {
				if (lastRight) {
					lastTv.getLayoutParams().width = halfWidth - 6;
					lp.setMargins(halfWidth + 1, space, 5, 0);
				} else {
					lastTv.getLayoutParams().width = halfWidth - 6;
					lp.setMargins(5, space, halfWidth + 1, 0);
				}
			}
			lastRight = !lastRight;
			lastTv = tv;
			tv.setLayoutParams(lp);

			// runterscrollen
			if (!firstAppointmentFound) {
				firstAppointmentFound = true;
				sv.scrollTo(0, space);
			}

			final Appointment appointmentConnectedToClick = appointmentToDraw;
			tv.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(final View v) {
					Intent intent = new Intent(CalendarOverviewActivity.this,
							ShowAppointment.class);
					intent.putExtra(APPOINTMENT_ID,
							appointmentConnectedToClick.getId());
					startActivityForResult(intent, 0);
				}
			});
			ll.addView(tv);

			if (appointments.hasNext()) {
				appointmentToDraw = appointments.next();
				if (appointmentToDraw.getStartdate().compareTo(day) == 1) {
					// naechster Termin faengt morgen an: fertig
					return;
				}
			} else {
				// alle Termine abgearbeitet: fertig
				return;
			}
		}
	}

	/**
	 * F&uuml;llt das &uuml;bergebene LinearLayout mit der grafischen
	 * Repr&auml;sentation von Terminen, die an einem bestimmten Tag
	 * stattfinden.
	 * 
	 * @param sv
	 *            ScrollView, die bis zum ersten Termin heruntergescrollt werden
	 *            soll.
	 * @param ll
	 *            LinearLayout, auf das Termine gezeichnet werden sollen
	 * @param day
	 *            Tag, dessen Termine gezeichnet werden soll
	 * @param smallFont
	 *            Ob der Text klein geschrieben werden sein soll.
	 */
	private void updateDayAppointments(final ScrollView sv,
			final LinearLayout ll, final Date day, final boolean smallFont) {
		// alte Termine aus dem LinearLayout loeschen:
		ll.removeAllViews();

		Iterator<Appointment> appointments = calendar.getAppointments()
				.iterator();
		if (!appointments.hasNext()) {
			// keine Termine eingetragen: fertig
			return;
		}

		// Finde den ersten Termin, der Heute aufhoert:
		Appointment lastCheckedAppointment = appointments.next();
		while (appointments.hasNext()
				&& lastCheckedAppointment.getEnddate().compareTo(day) == -1) {
			lastCheckedAppointment = appointments.next();
		}

		if (lastCheckedAppointment.getEnddate().compareTo(day) == -1
				|| lastCheckedAppointment.getStartdate().compareTo(day) == 1) {
			// alle Termine sind entweder nach, oder vor heute: fertig
			return;
		}

		// gültige Termine sammeln
		List<Appointment> appointmentsToDraw = new LinkedList<Appointment>();
		Appointment appointmentToDraw = lastCheckedAppointment;
		while (true) {
			appointmentsToDraw.add(appointmentToDraw);
			if (appointments.hasNext()) {
				appointmentToDraw = appointments.next();
				if (appointmentToDraw.getStartdate().compareTo(day) == 1) {
					// naechster Termin faengt morgen an: fertig
					break;
				}
			} else {
				// alle Termine abgearbeitet: fertig
				break;
			}
		}
		List<LinearLayout> clusters = updateDayAppointmentsHelper(
				appointmentsToDraw, smallFont, day);
		for (LinearLayout cluster : clusters) {
			ll.addView(cluster);
		}
		ll.invalidate();
		// TODO runterscrollen testen
		int pixelsToScroll = 8 * 60;
		if (appointmentsToDraw.size() > 0) {
			Appointment firstApp = appointmentsToDraw.get(0);
			if (startsBefore(firstApp, day)) {
				pixelsToScroll = 0;
			} else {
				pixelsToScroll = (int) (firstApp.getStartInMillis() / 60000);
			}
		}
	}

	private List<LinearLayout> updateDayAppointmentsHelper(
			final List<Appointment> appointments, final boolean smallFont,
			final Date day) {

		class Event {
			boolean isStart;
			Appointment appointment;
			int column; // nur für End-Events relevant

			public Event(final boolean isStart, final Appointment appointment,
					final int column) {
				super();
				this.isStart = isStart;
				this.appointment = appointment;
				this.column = column;
			}

			// TODO wird nur zu Debugzwecken genutzt: löschen
			public String toString() {
				return "(" + (isStart ? "Start" : "Ende") + " // "
						+ appointment + " // " + column + ")\n";
			}
		}

		// Initialisierung -----------------------------------------------------
		// mehr als 6 Spalten sind nicht möglich
		boolean[] columnIsOccupied = new boolean[5];
		Arrays.fill(columnIsOccupied, false);
		long[] lastColumnEndTimes = new long[columnIsOccupied.length];
		Arrays.fill(lastColumnEndTimes, day.getTimeInMillis());

		// "eventQueue" assoziiert einen Zeitpunkt mit einem "Event".
		SortedMap<Long, Event> eventQueue = new TreeMap<Long, Event>();
		for (Appointment app : appointments) {
			eventQueue.put(app.getStartInMillis(), new Event(true, app, 0));
		}

		List<LinearLayout> columns = new ArrayList<LinearLayout>(6);
		List<LinearLayout> clusters = new LinkedList<LinearLayout>();
		LinearLayout currentCluster = makeHorizontalLayout();
		int parallel = 0;

		// Events durchlaufen -----------------------------------------------
		while (!eventQueue.isEmpty()) {
			Event event = eventQueue.remove(eventQueue.firstKey());
			Log.d("CalendarOverviewActivity", "eVENT " + event);
			Appointment appointment = event.appointment;
			if (event.isStart) {
				// ein Termin fängt an --------------------------------------
				parallel++;

				int columnIndex = 0;
				while (columnIsOccupied[columnIndex]) {
					columnIndex++;
				}
				if (columnIndex >= columns.size()) {
					LinearLayout newColumn = makeVerticalLayout();
					columns.add(newColumn);
				}
				eventQueue.put(appointment.getEndInMillis(), new Event(false,
						appointment, columnIndex));
				columnIsOccupied[columnIndex] = true;

			} else {
				// ein Termin endet --------------------------------------
				// Erste und letzte Minute des aktuellen Termins
				// wird zur berechnung der Hoehe des TextViews
				// verwendet.
				long startTime = day.getTimeInMillis();
				long endTime = startTime + (24 * 60 * 60 * 1000);
				long freeTime = 0;
				long lastEnd = day.getTimeInMillis();
				if (appointment.isAllday()
						|| (startsBefore(appointment, day) && endsAfter(
								appointment, day))) {
					// Termin geht von oben bis unten:
					// Werte bleiben, wie oben angegeben.
				} else {
					if (!startsBefore(appointment, day)) {
						// Termin faengt nach 00:00 an
						startTime = appointment.getStartInMillis();
						freeTime = startTime - lastColumnEndTimes[event.column];
					}

					if (!endsAfter(appointment, day)) {
						// Termin endet vor 00:00
						endTime = appointment.getEndInMillis();
						lastEnd = endTime;
					}
				}
				Log.d("CalendarOverviewActivity", "start " + startTime
						+ " end " + endTime);

				// TextView Anlegen´
				TextView tv = new TextView(this);
				tv.setText(appointment.getName());
				tv.setBackgroundColor(getResources().getColor(
						R.color.android_light_blue)); // TODO Gibts die Farbe
														// vordefiniert?
				tv.setTextSize(smallFont ? 10 : 15);
				int height = (int) ((endTime - startTime) / (60 * 1000) * PIXEL_PER_MINUTE);
				int space = (int) ((freeTime + 1) / (60 * 1000) * PIXEL_PER_MINUTE);
				LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
						LayoutParams.MATCH_PARENT, height);
				lp.setMargins(5, space, 5, 0);
				tv.setLayoutParams(lp);
				tv.setHeight(height);
				tv.setMinimumHeight(height);
				final Appointment appointmentConnectedToClick = appointment;
				tv.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(final View v) {
						Intent intent = new Intent(
								CalendarOverviewActivity.this,
								ShowAppointment.class);
						intent.putExtra(APPOINTMENT_ID,
								appointmentConnectedToClick.getId());
						startActivityForResult(intent, 0);
					}
				});
				Log.d("CalendarOverviewActivity", "height= " + height);

				columns.get(event.column).addView(tv);
				lastColumnEndTimes[event.column] = lastEnd;
				columnIsOccupied[event.column] = false;

				parallel--;
				if (parallel == 0) {
					for (LinearLayout column : columns) {
						currentCluster.addView(column);
					}
					clusters.add(currentCluster);
					Arrays.fill(lastColumnEndTimes,
							appointment.getEndInMillis());

					currentCluster = makeHorizontalLayout();
					// Spalten leeren
					columns = new ArrayList<LinearLayout>(6);
				}
			}
		}

		return clusters;
	}

	private TextView makeTextView(String text, int height, int marginTop,
			int backgroundColor) {
		TextView result = new TextView(this);
		result.setText(text);
		result.setBackgroundColor(Color.BLUE);
		result.setTextSize(15);
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
				LayoutParams.MATCH_PARENT, height);
		lp.setMargins(1, 1, 1, 1);
		result.setLayoutParams(lp);
		return result;
	}

	private LinearLayout makeVerticalLayout() {
		LinearLayout result = new LinearLayout(this);
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
				LayoutParams.WRAP_CONTENT);
		lp.weight = 1;
		result.setLayoutParams(lp);
		result.setOrientation(LinearLayout.VERTICAL);

		return result;
	}

	private LinearLayout makeHorizontalLayout() {
		LinearLayout result = new LinearLayout(this);
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
				LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);

		result.setLayoutParams(lp);
		result.setOrientation(LinearLayout.HORIZONTAL);

		return result;
	}

	private boolean startsBefore(final Appointment appointment, final Date day) {
		return appointment.getStartdate().compareTo(day) == -1;
	}

	private boolean endsAfter(final Appointment appointment, final Date day) {
		return appointment.getEnddate().compareTo(day) == 1;
	}
}
