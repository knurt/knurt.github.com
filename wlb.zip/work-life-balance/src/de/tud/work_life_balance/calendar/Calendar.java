package de.tud.work_life_balance.calendar;

import java.io.Serializable;
import java.util.SortedSet;
import java.util.TreeSet;

import de.tud.work_life_balance.profil.Profile;

/**
 * Klasse, die eine Liste von Terminen speichert.
 * <p>
 * Diese Klasse bildet das Daten-Backend zum Kalender.<br>
 * Diese Klasse wird innerhalb des Profils serialisiert und im Dateisystem
 * gespeichert.
 * 
 * @see CalendarOverviewActivity
 * @see Profile
 * 
 */
public class Calendar implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	SortedSet<Appointment> appointments = new TreeSet<Appointment>();

	public Calendar(SortedSet<Appointment> appointments) {
		super();
		this.appointments = appointments;
	}

	public Calendar() {
		super();
	}

	/**
	 * @return the appointments
	 */
	public SortedSet<Appointment> getAppointments() {
		return appointments;
	}

	/**
	 * @param appointments
	 *            the termine to set
	 */
	public void setAppointments(SortedSet<Appointment> appointments) {
		this.appointments = appointments;
	}

	@Override
	public String toString() {
		return appointments.toString();
	}

	public SortedSet<Appointment> getAppointmentsBetween(long startMillis,
			long endMillis) {
		// evtl. koennte man den Code so umstrukturieren, dass man die
		// "subSet"-Methode
		// verwenden kann.
		// return calendar.getAppointments().subSet(start, end);

		TreeSet<Appointment> appointments = new TreeSet<Appointment>();
		for (Appointment app : getAppointments()) {
			if (app.getEndInMinutes() > (startMillis / Appointment.MILLIS_PER_MINUTE)
					&& app.getStartInMinutes() < (endMillis / Appointment.MILLIS_PER_MINUTE)) {
				appointments.add(app);
			}
		}
		return appointments;
	}

}
