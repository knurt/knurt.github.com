package de.tud.work_life_balance.calendar;

import java.util.ArrayList;

// TODO wird ICalender irgendwo verwendet? Wenn nein -> löschen
// Vielleicht wird es fuer das Erweiterungspaketinterface verwendet
public interface ICalender {

	public ArrayList getTermine();

	public ArrayList getTodayTermine();

	public ArrayList getTodo();

	public ArrayList getTodayTodo();

	public void editTermin(Date date, int terminName);
}
