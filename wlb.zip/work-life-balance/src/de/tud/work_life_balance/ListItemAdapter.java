package de.tud.work_life_balance;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Adapter fuer eine ListView. Listenelemente, die hier hinzugefuegt werden,
 * werden automatisch in der zugehoerigen ListView angezeigt.
 * <p>
 * Die Elemente, die angezeigt werden, sind {@link ListItem}s, die aus einem
 * Bild und einem Text bestehen.
 * <p>
 * Die Anordnung von Text und beschreibenden Bild ist in
 * "res/layout/listitem.xml" festgelegt.
 * 
 */
public class ListItemAdapter extends ArrayAdapter<ListItem> {

	private ArrayList<ListItem> items;

	public ListItemAdapter(Context context, int textViewResourceId,
			ArrayList<ListItem> items) {

		super(context, textViewResourceId, items);

		this.items = items;

	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		View v = convertView;

		if (v == null) {

			LayoutInflater vi = (LayoutInflater) getContext().getSystemService(
					Context.LAYOUT_INFLATER_SERVICE);

			v = vi.inflate(R.layout.listitem, null);

		}

		ListItem item = items.get(position);

		if (item != null) {

			TextView menueS = (TextView) v.findViewById(R.id.menueS);
			ImageView image = (ImageView) v.findViewById(R.id.avatar);

			if (item != null) {

				menueS.setText(item.text);

				if (item.getThumbnail() != null) {

					image.setImageDrawable(item.getThumbnail());

				}

			}

		}

		return v;

	}

}
